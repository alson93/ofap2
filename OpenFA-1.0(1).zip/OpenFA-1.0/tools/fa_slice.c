/*
 * fa_slice.c - the desktop vertical-slice entry point.
 *
 *   OpenFA                   open a window; show the title / world-select menu
 *                            if GData is found, else a test pattern. Click a
 *                            world circle to play it (GIUNGLA = world 1), or
 *                            use keyboard arrows / a controller D-pad and
 *                            confirm with Enter / controller A.
 *   OpenFA --gdata DIR       use this GData directory
 *   OpenFA --world N         skip the menu, boot straight into world N (1..4)
 *   OpenFA --tut             with --world: load the tutorial layout (WeltNt)
 *   OpenFA --end             with --world: boot into the boss arena (WeltNE);
 *                            in play, all 6 recipe pieces trigger this too
 *   OpenFA --grid            with --world: draw the debug cell overlay
 *   OpenFA --tone            keep the 440 Hz tone on (default: 1 s at start)
 *   OpenFA --silent          no startup tone
 *   OpenFA --frames N        run N frames headless and print stats
 *   OpenFA --seed N          pin the enemy RNG (default: wall clock)
 *
 * Menu: mouse, keyboard arrows, or a controller D-pad select a world;
 *       Enter / controller A confirms it.
 * Level (--world N): arrows walk, A jump, S throw, D switch character.
 *   Esc / controller SELECT returns to the main menu.
 *   ENTER / controller START enables local co-op: the joining input takes
 *   Milchschnitte, the other takes Pinguì (keyboard layouts swap to match).
 *   T (or LB on Milchschnitte's pad) teleports her near Pinguì.
 *   P  toggle free-move (dev): no-clip fly, hold A to dash.
 *   I  skip straight to this world's boss arena (dev).
 *
 * GData lookup order: --gdata DIR, then <exe dir>/GData, then (POSIX)
 * ~/.local/share/OpenFA/GData (this is what a Flatpak install uses - see
 * flatpak/io.github.Mayo1970.OpenFA.yml), then ./GData.
 * If none is found the program shows an error and exits; only --frames
 * (automation) and the --tone / --grid test pattern may run without GData.
 */
#include "fa/fa_app.h"
#include "fa/fa_platform.h"
#include "fa/fa_input.h"
#include "fa/fa_surface.h"
#include "fa/fa_w01.h"
#include "fa/fa_map.h"
#include "fa/fa_render.h"
#include "fa/fa_entity.h"
#include "fa/fa_beh.h"
#include "fa/fa_player.h"
#include "fa/fa_charspr.h"
#include "fa/fa_collide.h"
#include "fa/fa_death.h"
#include "fa/fa_menu.h"
#include "fa/fa_hiscore.h"
#include "fa/fa_credits.h"
#include "fa/fa_hud.h"
#include "fa/fa_audio.h"
#include "fa/fa_vfs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#if defined(_WIN32)
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
#elif defined(__SWITCH__)
#  include <switch.h>
#else
#  include <unistd.h>   /* readlink - exe-dir GData probe on POSIX */
#endif

#if defined(FA_HAVE_SDL2)
#  include <SDL.h>       /* SDL_ShowSimpleMessageBox for the no-GData error */
#endif

typedef struct {
    fa_menu    *menu;
    fa_credits *credits;         /* non-NULL = the credits screen is up      */
    fa_hiscore *scores;          /* non-NULL = the high-score screen is up */
    int       show_scores;       /* request from the menu, handled next tick */
    int       hover;             /* menu button under the pointer, or -1 */
    int       menu_focus;        /* keyboard / D-pad focused world, or -1 */
    int       pending_world;     /* 1..4: load this world next tick      */
    int       world;             /* 1..4: the world currently loaded     */
    int       in_end;            /* in the boss arena (WeltNE), not the world */
    int       end_pending;       /* recipe complete: load WeltNE next tick    */
    int       boss_win_timer;    /* >0 counting down to CLASSIFICA            */
    int       tut_reload_pending;/* tutorial cleared - reload as WeltN        */
    int       want_quit;
    char      gdata[600];

    int          have_map;
    fa_w01       bg;
    fa_map       map;
    fa_tileset  *tiles;
    fa_entity_store *ents;
    fa_beh      *beh;            /* per-ObjNr enemy behaviour               */
    fa_hud      *hud;           /* score / health / ammo panel             */
    int          health;        /* 0x45F014, 100 max, 20 per hit           */
    int          ammo;         /* 0x45ED34, snowballs 0..10               */
    int          items[6];     /* 0x45EFD4, recipe-piece flags            */
    int          dirty_shot;   /* collect_dirtyballs was taken            */
    fa_camera    cam;
    fa_player pl;
    fa_player pl2;                /* co-op Milchschnitte */
    int       use_player;
    int       coop;
    int       p1_controller;      /* -1 = keyboard role, otherwise pad 0..1 */
    int       p2_controller;      /* -1 = keyboard role, otherwise pad 0..1 */
    int       keyboard_roles_swapped; /* ENTER-only: P2 main keyboard, P1 alt */
    int       death_player;       /* player that triggered the shared KO       */
    int       freemove;         /* P toggle: fly through the level, no clip  */

    /* enemy RNG seed: time() like the retail exe (0x42AE27), or --seed N. */
    uint32_t  rng_seed;
    int       rng_seed_set;

    /* health 0 ends the run. fa_death times the KO hold + fade with the level
     * still running; on DONE the level is torn down for the CLASSIFICA screen
     * then the menu. No restart, no lives. */
    fa_death  death;
    /* solid probe ctx: terrain + the lift/block layer */
    struct { const fa_map *map; const fa_tileset *ts; fa_entity_store *ents; } coll;

    fa_cs_sheet kid_sheet[2];    /* 0 = Pinguì, 1 = Milchschnitte */
    fa_cs_anim  kid_anim[2];
    int         have_kids;
    int         kid_was_crouch;  /* to trigger the stand-up animation */
    int         kid_rise;        /* ticks left in the crouch-rise pose */
    int         grid;
    int       tone;         /* --tone: a continuous 440 Hz tone            */
    int       want_chime;   /* default: a 1 s startup tone, then silence   */
    int       chime_pos;    /* frames of chime emitted so far              */
    double    tone_phase;

    fa_audio *audio;        /* mixer; NULL without GData / --mute          */
    int       mute;         /* --mute: create no mixer                     */
    int       vol;          /* --vol 0..255, <0 = default (full)          */
    int       swap_was;     /* previous tick's FA_PST_SWAP flag            */
    int       idle_was;     /* previous tick's s->pl.idle_kind (voice edge)*/
    int       jump_was;     /* previous tick's FA_PST_JUMP flag            */
    int       thr_was;      /* previous tick's throw_anim > 0              */
    int       glide_was;    /* previous tick's Pinguì glide flag          */

    uint32_t  cr_act_was;   /* prev tick's action mask (credits skip)      */
    uint32_t  menu_nav_seen;/* suppress a held edge across multi-tick frames */
    int       score;        /* pickups collected                          */
    int       hurt_cd;      /* ticks of hit invulnerability left          */
    int       push_was;     /* previous tick was shoving a block          */
    int       kid_was_crouch2;
    int       kid_rise2;
    int       jump_was2;
    int       thr_was2;
    int       glide_was2;
    int       push_was2;

    /* physics-tuning overrides (px/tick), <=0 = keep the default */
    double    ov_gravity, ov_jumpvel, ov_jumpvel2, ov_runspeed, ov_airaccel;
    /* camera / box tuning overrides (whole px), <=0 = keep the default */
    int       ov_bboxw, ov_bboxh, ov_camrail, ov_camband, ov_cambias;
} slice;

static void slice_focus_first_menu(slice *s)
{
    s->menu_focus = s->menu ? 0 : -1;
    s->hover = s->menu ? 0 : -1;
    s->menu_nav_seen = 0;
    if (s->menu) {
        for (int i = 0; i < fa_menu_button_count(s->menu); i++)
            fa_menu_set_state(s->menu, i, FA_MENU_REST);
        fa_menu_set_state(s->menu, 0, FA_MENU_HOVER);
    }
}

static void slice_set_menu(slice *s, fa_menu *menu)
{
    s->menu = menu;
    slice_focus_first_menu(s);
}

static void slice_merge_pad_movement(const fa_frame_input *fi, uint32_t *m)
{
    uint32_t b = fi->pad_down;
    if ((b & (1u << FA_PAD_DPAD_LEFT)) || fi->pad_lx < -0.35f)
        *m |= 1u << FA_ACT_LEFT;
    if ((b & (1u << FA_PAD_DPAD_RIGHT)) || fi->pad_lx > 0.35f)
        *m |= 1u << FA_ACT_RIGHT;
    if ((b & (1u << FA_PAD_DPAD_UP)) || fi->pad_ly < -0.35f)
        *m |= 1u << FA_ACT_UP;
    if ((b & (1u << FA_PAD_DPAD_DOWN)) || fi->pad_ly > 0.35f)
        *m |= 1u << FA_ACT_DOWN;

    /* Xbox-reference face layout: A jumps, B throws, Y swaps the active character.
     * SDL_GameController supplies these as logical buttons on other layouts. */
    if (b & (1u << FA_PAD_A)) *m |= 1u << FA_ACT_JUMP;
    if (b & (1u << FA_PAD_B)) *m |= 1u << FA_ACT_FIRE;
    if (b & (1u << FA_PAD_Y)) *m |= 1u << FA_ACT_SPARE;
}

/* Gameplay mapping for one controller slot.  The legacy helper above is kept
 * for the menu and for old callers that only know about pad slot 0. */
static uint32_t slice_pad_actions(const fa_frame_pad *pad)
{
    uint32_t m = 0;
    uint32_t b = pad ? pad->down : 0;
    float lx = pad ? pad->lx : 0.0f;
    float ly = pad ? pad->ly : 0.0f;
    if ((b & (1u << FA_PAD_DPAD_LEFT)) || lx < -0.35f)
        m |= 1u << FA_ACT_LEFT;
    if ((b & (1u << FA_PAD_DPAD_RIGHT)) || lx > 0.35f)
        m |= 1u << FA_ACT_RIGHT;
    if ((b & (1u << FA_PAD_DPAD_UP)) || ly < -0.35f)
        m |= 1u << FA_ACT_UP;
    if ((b & (1u << FA_PAD_DPAD_DOWN)) || ly > 0.35f)
        m |= 1u << FA_ACT_DOWN;
    if (b & (1u << FA_PAD_A)) m |= 1u << FA_ACT_JUMP;
    if (b & (1u << FA_PAD_B)) m |= 1u << FA_ACT_FIRE;
    if (b & (1u << FA_PAD_Y)) m |= 1u << FA_ACT_SPARE;
    return m;
}

static uint32_t slice_player_actions(const slice *s, const fa_frame_input *fi,
                                     int player)
{
    uint32_t m;
    if (!s->coop)
        return player == 0 ? fi->actions | slice_pad_actions(&fi->pads[0]) : 0;

    if (player == 0) {
        m = s->p1_controller >= 0 && s->p1_controller < FA_APP_MAX_PADS
          ? slice_pad_actions(&fi->pads[s->p1_controller])
          : (s->keyboard_roles_swapped ? fi->keyboard2_actions
                                       : fi->keyboard_actions);
    } else {
        m = s->p2_controller >= 0 && s->p2_controller < FA_APP_MAX_PADS
          ? slice_pad_actions(&fi->pads[s->p2_controller])
          : (s->keyboard_roles_swapped ? fi->keyboard_actions
                                       : fi->keyboard2_actions);
    }
    /* Character switching is deliberately unavailable in co-op. */
    return m & ~FA_PI_SWITCH;
}

static void slice_teleport_milch(slice *s);

static int slice_join_coop(slice *s, const fa_frame_input *fi)
{
    if (s->coop) return 0;

    int join_pad = -1;
    for (int i = 0; i < FA_APP_MAX_PADS; i++) {
        if (fi->pads[i].pressed & (1u << FA_PAD_START)) {
            join_pad = i;
            break;
        }
    }
    int join_keyboard = (fi->edit_pressed & FA_EDIT_ENTER) != 0;
    if (join_pad < 0 && !join_keyboard) return 0;

    s->coop = 1;
    /* Co-op always has a stable role split, even if single-player had
     * previously switched the active character. */
    s->pl.character = 0;
    s->pl.swap_timer = 0;
    if (s->pl.state == FA_PST_SWAP) s->pl.state = FA_PST_STAND;
    s->p2_controller = join_pad;
    s->p1_controller = -1;
    s->keyboard_roles_swapped = 0;
    if (join_pad >= 0) {
        /* When two pads are present, the pad that joined gets Milchschnitte
         * and the other pad remains Pinguì's controller. */
        for (int i = 0; i < FA_APP_MAX_PADS; i++) {
            if (i != join_pad && fi->pads[i].connected) {
                s->p1_controller = i;
                break;
            }
        }
    } else {
        /* ENTER joins from the keyboard, so the keyboard becomes
         * Milchschnitte's input. If a pad is attached, it remains Pinguì's
         * input; otherwise the alternate keyboard layout becomes Pinguì's
         * input. */
        s->p2_controller = -1;
        s->keyboard_roles_swapped = 1;
        for (int i = 0; i < FA_APP_MAX_PADS; i++) {
            if (fi->pads[i].connected) {
                s->p1_controller = i;
                break;
            }
        }
    }
    slice_teleport_milch(s);
    const char *pingui = s->p1_controller >= 0 ? "controller"
        : (s->keyboard_roles_swapped ? "I/J/K/L + U/O" : "keyboard");
    const char *milch = s->p2_controller >= 0 ? "controller"
        : (s->keyboard_roles_swapped ? "keyboard (T teleport)"
                                     : "I/J/K/L + U/O (T teleport)");
    printf("local co-op enabled: Pinguì=%s, Milchschnitte=%s\n",
           pingui, milch);
    return 1;
}

static void slice_teleport_milch(slice *s)
{
    int px = fa_player_px(&s->pl);
    int side = s->pl.facing == FA_FACE_RIGHT ? -1 : 1;
    int x = px + side * 48;
    if (x < s->pl2.t.body_hw) x = s->pl2.t.body_hw;
    if (x > s->map.world_w - s->pl2.t.body_hw)
        x = s->map.world_w - s->pl2.t.body_hw;
    s->pl2.x = FA_FIX(x);
    s->pl2.y = s->pl.y;
    s->pl2.vx = s->pl2.vy = 0;
    s->pl2.on_ground = s->pl.on_ground;
    s->pl2.state = FA_PST_STAND;
    s->pl2.gliding = 0;
    s->pl2.throw_anim = 0;
    s->pl2.throw_timer = 0;
    s->pl2.facing = s->pl.facing;
    s->pl2.idle_kind = s->pl2.idle_play = 0;
    s->pl2.idle_timer = s->pl2.t.idle_delay;
}

/* Decode one .W01 frame and blit it colour-keyed, centred on (cx, cy).
 * Returns 1, or 0 on no sheet / bad frame / decode failure. */
static int blit_w01_centered(const fa_surface *dst, const fa_w01 *w,
                             int frame, int cx, int cy)
{
    if (!w || frame < 0 || frame >= fa_w01_count(w)) return 0;
    int fw = 0, fh = 0;
    if (fa_w01_frame_size(w, frame, &fw, &fh) != 0 || fw <= 0 || fh <= 0)
        return 0;
    uint16_t *px = (uint16_t *)malloc((size_t)fw * fh * sizeof *px);
    if (!px) return 0;
    if (fa_w01_decode(w, frame, px) != 0) { free(px); return 0; }
    fa_surface src;
    fa_surface_wrap(&src, px, fw, fh, 0);
    fa_blit_keyed(dst, cx - fw / 2, cy - fh / 2, &src, NULL, NULL, FA_COLORKEY);
    free(px);
    return 1;
}

static void apply_tuning(slice *s)
{
    fa_player *p[2] = { &s->pl, &s->pl2 };
    for (int i = 0; i < 2; i++) {
        if (s->ov_gravity   > 0) p[i]->t.gravity     = (int32_t)(s->ov_gravity   * FA_FIX_ONE);
        if (s->ov_jumpvel   > 0) p[i]->t.jump_vel    = -(int32_t)(s->ov_jumpvel  * FA_FIX_ONE);
        if (s->ov_jumpvel2  > 0) p[i]->t.jump_vel_c1 = -(int32_t)(s->ov_jumpvel2 * FA_FIX_ONE);
        if (s->ov_runspeed  > 0) p[i]->t.run_speed   = (int32_t)(s->ov_runspeed  * FA_FIX_ONE);
        if (s->ov_airaccel  > 0) p[i]->t.air_accel   = (int32_t)(s->ov_airaccel  * FA_FIX_ONE);
        if (s->ov_bboxw     > 0) p[i]->t.body_hw     = s->ov_bboxw;
        if (s->ov_bboxh     > 0) p[i]->t.body_h      = s->ov_bboxh;
    }
}

static int load_world(slice *s, const char *maps, int world,
                      const char *w01suf, const char *w02suf);

/* ladder probe for the climb state: a plane-2 grid entry with code bit 0. */
static int slice_ladder(int px, int py, void *ctx)
{
    return fa_map_ladder_at((const fa_map *)ctx, px, py);
}

/* terrain collision class at a world pixel (0 none / 1 solid / 2 one-way),
 * per-pixel via the decoded atlas so slopes follow their diagonal. */
typedef struct { const fa_map *map; const fa_tileset *ts;
                 fa_entity_store *ents; } coll_ctx;

static int slice_terrain(int px, int py, void *ctx)
{
    const coll_ctx *c = ctx;
    return fa_render_solid_px(c->map, c->ts, px, py);
}

/* terrain OR a lift top / pushable block: the player stands on rafts and
 * cannot walk through blocks. */
static int slice_solid(int px, int py, void *ctx)
{
    const coll_ctx *c = ctx;
    int r = fa_render_solid_px(c->map, c->ts, px, py);
    if (!r && c->ents) {
        int e = fa_entity_solid_at(c->ents, px, py);   /* 1 block / 2 lift */
        if (e) r = e;
    }
    return r;
}

/* a pushable block at (px,py) -> Milchschnitte enters PUSH. */
static int slice_pushable(int px, int py, void *ctx)
{
    return fa_entity_pushable_at((const fa_entity_store *)ctx, px, py);
}

/*
 * a HAZARD tile at world pixel (px,py): a non-empty plane-2 cell with attr bit
 * 0x80 (spikes / lava / pit pool), matching the exe check at fcn.0041A290.
 * We sample the feet cell AND a few px below, because fa_collide rests the character
 * ~1 px above the pixel it lands on and would otherwise miss the Welt1 band.
 */
static int slice_hazard(const fa_map *m, int px, int py)
{
    int tw = m->info.tile_w > 0 ? m->info.tile_w : 32;
    int th = m->info.tile_h > 0 ? m->info.tile_h : 32;
    if (px < 0 || py < 0) return 0;
    for (int dy = 0; dy <= 4; dy += 4) {
        fa_map_entry e = fa_map_cell_entry(m, px / tw, (py + dy) / th, 2);
        if (!fa_map_entry_empty(e) && (e.attr & FA_MAP_ATTR_HAZARD))
            return 1;
    }
    return 0;
}

/* --- behaviour-layer hooks --- */
static int beh_terrain(int px, int py, void *ctx)
{
    slice *s = (slice *)ctx;
    return fa_render_solid_px(s->coll.map, s->coll.ts, px, py);
}
static void beh_score(int add, void *ctx)
{
    slice *s = (slice *)ctx;
    s->score += add;
}

/*
 * one collected DetailGroup-1 pickup, effect per ObjNr (exe 0x411c18..0x411d46):
 *   48/49/50 score +=100   51 health +=40   52 ammo=10   53..58 score +=1000+flag
 *   59 score +=10000   60 ammo=10 "dirty"
 * Energy and both ammo pickups (51/52/60) respawn after 1200 ticks; the rest are
 * permanent. Returns the respawn delay (0 = permanent).
 */
static int beh_pickup(int obj_nr, int detail_group, void *ctx)
{
    slice *s = (slice *)ctx;
    (void)detail_group;
    switch (obj_nr) {
        case 48: case 49: case 50: s->score += 100;   break;
        case 51:
            s->health += 40;
            if (s->health > 100) s->health = 100;
            return 1200;
        case 52: s->ammo = 10; s->dirty_shot = 0;     return 1200;
        case 53: case 54: case 55: case 56: case 57: case 58:
            s->score += 1000;
            s->items[obj_nr - 53] = 1;
            break;
        case 59: s->score += 10000;                   break;
        case 60: s->ammo = 10; s->dirty_shot = 1;     return 1200;
        default: break;
    }
    return 0;
}
static void beh_sfx(int ev, int obj, void *ctx)
{
    slice *s = (slice *)ctx;
    if (!s->audio) return;
    switch (ev) {
        case FA_BEH_SFX_BOSS_KO_ANIM:                   /* robot: RBKO fr56       */
            if (obj == 14) fa_audio_event(s->audio, FA_SND_W3_BOSS_KO);
            break;
        case FA_BEH_SFX_BOSS_LAND:                      /* yeti: hop land         */
            if (obj == 9) fa_audio_event(s->audio, FA_SND_W2_BOSS_LAND);
            break;
        case FA_BEH_SFX_BOSS_HURT:                      /* yeti: hit fr69         */
            if (obj == 9) fa_audio_event(s->audio, FA_SND_W2_BOSS_HURT);
            break;
        case FA_BEH_SFX_BOSS_VOICE_CUT:                 /* yeti: hit cuts         */
            fa_audio_stop(s->audio, FA_CH_VOICE);       /* the roar/taunt line     */
            fa_audio_stop(s->audio, FA_CH_BOSS);
            break;
        case FA_BEH_SFX_BOSS_KO:
            if (obj == 14) { fa_audio_event(s->audio, FA_SND_W3_BOSS_DEFEAT); break; }
            /* fall through */
        case FA_BEH_SFX_ENEMY_KO:
        case FA_BEH_SFX_FREEZE:    /* snowman: 0x422B60(3, alsf04) at 0x41AC5C */
                                  fa_audio_event(s->audio, FA_SND_ENEMY_DEFEAT); break;
        case FA_BEH_SFX_ENEMY_LAUNCH: break;   /* alsf04 already played at KO  */
        case FA_BEH_SFX_ENEMY_ATTACK:          /* the dive - one cue per bird  */
            fa_audio_event(s->audio,
                obj == 11 ? FA_SND_ENEMY_CHARGE     :
                obj == 6  ? FA_SND_ENEMY_DIVE_EAGLE :
                obj == 16 ? FA_SND_ENEMY_DIVE_BEE   : FA_SND_ENEMY_DIVE);
            break;
        case FA_BEH_SFX_ENEMY_SHOT:            /* the throw - egg robot differs */
            fa_audio_event(s->audio,
                obj == 14 ? FA_SND_W3_BOSS_SHOT :       /* robot bolt          */
                obj == 18 ? FA_SND_W4_BOSS_SHOT :       /* milk particle       */
                obj == 12 ? FA_SND_ENEMY_THROW_EGG : FA_SND_ENEMY_THROW);
            break;
        case FA_BEH_SFX_BOSS_CHARGE:                    /* boss wind-up cue     */
            fa_audio_event(s->audio,
                obj == 18 ? FA_SND_W4_BOSS_DRINK        /* octopus slurp       */
                          : FA_SND_W3_BOSS_CHARGE);     /* robot wind-up       */
            break;
        case FA_BEH_SFX_BOSS_HIT:
            /* World 3: button push / pipe drop / the robot taking a hit each
             * have their own w3sf cue. */
            fa_audio_event(s->audio,
                (obj == 83 || obj == 84) ? FA_SND_W3_BUTTON :
                obj == 85                ? FA_SND_W3_PIPE :
                obj == 14                ? FA_SND_W3_BOSS_HIT
                                         : FA_SND_ENEMY_KNOCK);
            break;
        case FA_BEH_SFX_BROESEL_BREAK: {   /* 0x422B60(6, knusper.wav) at 0x416D2D */
            int clip = fa_audio_load(s->audio, "SDat/knusper.wav");
            if (clip >= 0) fa_audio_play_clip(s->audio, clip, 6, 0, 256);
            break;
        }
        default: break;
    }
}

/*
 * A streamed voice line. Route by file stem: gb/yb/rb/ob NNNN are boss lines
 * (lane 18), pa/pat NNNN are the Paradiso mascot (lane 17).
 */
static void beh_voice(const char *rel_wav, void *ctx)
{
    slice *s = (slice *)ctx;
    if (!rel_wav) return;
    const char *base = strrchr(rel_wav, '/');
    base = base ? base + 1 : rel_wav;
    int c0 = base[0] | 0x20, c1 = base[1] | 0x20;   /* fold case */
    int boss = c1 == 'b' &&
               (c0 == 'g' || c0 == 'y' || c0 == 'r' || c0 == 'o');
    int lane = boss ? FA_CH_BOSS : FA_CH_VOICE;
    printf("voice -> %s\n", rel_wav);   /* console cue (Paradiso / boss) */
    if (s->audio) fa_audio_play_stream(s->audio, rel_wav, lane, 0);
}

static int beh_voice_busy(void *ctx)
{
    slice *s = (slice *)ctx;
    if (!s->audio) return 0;
    return fa_audio_channel_busy(s->audio, FA_CH_VOICE) ||
           fa_audio_channel_busy(s->audio, FA_CH_BOSS);
}

/*
 * The tutorial's last Paradiso finished its pat0020 line (exe 0x4159BD).
 * Persist tut.ini[world] = 1, then queue a reload of the same world, which now
 * loads as the normal level since slice_tut_seen reads the file we just wrote.
 */
static void beh_tutorial_done(void *ctx)
{
    slice *s = (slice *)ctx;
    if (s->world >= 1 && s->world <= 4) {
        fa_vfs v;
        if (fa_vfs_init_default(&v, s->gdata, "FreshAdventures") == 0)
            fa_vfs_set_tut_world_seen(&v, s->world, 1);
    }
    printf("tutorial cleared -> Welt%d (normal level)\n", s->world);
    s->tut_reload_pending = 1;
}

/*
 * Arm the world's positional loops (exe 0x412643): world 3 = w3sf01 slot 8
 * (electric floor) + w3sf11 slot 14 (robot), world 4 = w4sf03 slot 14 (bee).
 * Each starts muted; slice_posloops() rides the volume by distance each tick.
 */
static void set_world_ambient(slice *s, int world)
{
    if (!s->audio) return;
    fa_audio_stop(s->audio, 8);
    fa_audio_stop(s->audio, 14);
    if (world == 3) {
        fa_audio_event(s->audio, FA_SND_AMBIENT_W3);   /* w3sf01 slot 8  */
        fa_audio_event(s->audio, FA_SND_UFO);          /* w3sf11 slot 14 */
        fa_audio_set_channel_gain(s->audio, 8, 0);
        fa_audio_set_channel_gain(s->audio, 14, 0);
    } else if (world == 4) {
        fa_audio_event(s->audio, FA_SND_BEE_LOOP);     /* w4sf03 slot 14 */
        fa_audio_set_channel_gain(s->audio, 14, 0);
    }
}

/* Stop every SFX lane plus the voice channels. Called on any level or menu
 * transition so ambient / proximity loops never bleed across screens. */
static void slice_audio_hush(slice *s)
{
    if (!s->audio) return;
    fa_audio_stop_sfx(s->audio);
    fa_audio_stop(s->audio, FA_CH_VOICE);
    fa_audio_stop(s->audio, FA_CH_BOSS);
}

/* ================================================================== *
 *  Positional loops  (exe emitter 0x412EE0 + volume pass 0x41139D)
 *
 *  One looping WAV per slot runs the whole level; its volume each frame comes
 *  from the min squared distance between screen centre and the corners of any
 *  live emitter's box. Curve: full within 350 px, linear-in-distance^2 ramp to
 *  ~-50 dB by 1063 px, then silence. A far emitter is just gain 0, never stopped.
 * ================================================================== */
#define POSLOOP_FULL_PX   350   /* <= : full volume                          */
#define POSLOOP_FADE_PX  1063   /* >= : muted (sqrt of the exe's 0x113E10)   */
#define POSLOOP_CULL_X   1200   /* corner ignored past this |dx| ...         */
#define POSLOOP_CULL_Y    900   /* ... or this |dy| (exe 0x412EE0)           */

/* min squared distance -> lane gain (/256): a dB value linear in distance^2
 * from 0 to ~-50 across the band, then hard-mute, converted to amplitude. */
static int posloop_gain(long d2)
{
    long full = (long)POSLOOP_FULL_PX * POSLOOP_FULL_PX;
    long fade = (long)POSLOOP_FADE_PX * POSLOOP_FADE_PX;
    if (d2 <= full) return 256;
    if (d2 >= fade) return 0;
    double t  = (double)(d2 - full) / (double)(fade - full);   /* 0..1     */
    double db = -50.0 * t;                                     /* exe ramp */
    int g = (int)(256.0 * pow(10.0, db / 20.0) + 0.5);
    return g < 0 ? 0 : (g > 256 ? 256 : g);
}

/* Ride `lane`'s gain from the nearest live emitter of ObjNr `o1` or `o2` (-1
 * skips). `guard` = 1 gates each emitter on fa_beh_emitter_live; 0 = any
 * active record emits. */
static void posloop_update(slice *s, int o1, int o2, int lane, int guard)
{
    if (!s->audio || !s->ents) return;
    long cx = (long)s->cam.x + FA_FB_W / 2;
    long cy = (long)s->cam.y + FA_FB_H / 2;
    long best = -1;
    int n = fa_entity_count(s->ents);
    for (int i = 0; i < n; i++) {
        const fa_entity_rec *e = fa_entity_at(s->ents, i);
        if (!e || !e->active) continue;
        if (e->obj_nr != o1 && e->obj_nr != o2) continue;
        if (guard && s->beh && !fa_beh_emitter_live(s->beh, i)) continue;
        int x0, y0, x1, y1;
        if (fa_entity_frame_box(s->ents, i, &x0, &y0, &x1, &y1) != 0) {
            x0 = x1 = e->x; y0 = y1 = e->y;
        }
        const int cxs[4] = { x0, x1, x0, x1 };
        const int cys[4] = { y0, y0, y1, y1 };
        for (int k = 0; k < 4; k++) {
            long dx = cxs[k] - cx, dy = cys[k] - cy;
            if (dx < -POSLOOP_CULL_X || dx > POSLOOP_CULL_X) continue;
            if (dy < -POSLOOP_CULL_Y || dy > POSLOOP_CULL_Y) continue;
            long d2 = dx * dx + dy * dy;
            if (best < 0 || d2 < best) best = d2;
        }
    }
    fa_audio_set_channel_gain(s->audio, lane, best < 0 ? 0 : posloop_gain(best));
}

/* per-tick: drive whichever positional loops this world armed. */
static void slice_posloops(slice *s)
{
    if (s->world == 3) {
        posloop_update(s, 355, 356,  8, 0);   /* electric floor -> w3sf01 */
        posloop_update(s,  13,  -1, 14, 1);   /* flying robot   -> w3sf11 */
    } else if (s->world == 4) {
        posloop_update(s,  16,  -1, 14, 1);   /* bee            -> w4sf03 */
    }
}

/*
 * Spawn point: the level's ObjNr 1000 entity record carries the X/Y (exe
 * 0x4118F5). Falls back to a terrain scan when there is no entity layer.
 */
static void find_spawn(slice *s, int *out_x, int *out_y)
{
    if (s->ents && fa_entity_player_start(s->ents, out_x, out_y)) return;

    const fa_map *m = &s->map;
    for (int x = 80; x <= 400; x += 16) {
        int y = 0;
        for (; y < m->world_h; y += 8)
            if (fa_map_solid_class(m, x, y) == FA_SOLID_FULL) break;
        if (y < m->world_h) { *out_x = x; *out_y = y; return; }
    }
    *out_x = 96;
    *out_y = m->world_h - 32;
}

/* place the character on solid ground, bind collision, frame the camera. */
static void wire_level(slice *s)
{
    int sx, sy;
    find_spawn(s, &sx, &sy);
    printf("spawn: character at %d,%d (world %dx%d)\n", sx, sy,
           s->map.world_w, s->map.world_h);
    fa_player_init(&s->pl, sx, sy);
    int sx2 = sx + 64;
    if (sx2 > s->map.world_w - 16) sx2 = s->map.world_w - 16;
    if (sx2 < 16) sx2 = 16;
    fa_player_init(&s->pl2, sx2, sy);
    s->pl2.character = 1;       /* co-op partner is always Milchschnitte */
    s->pl.t.floor_y = FA_FIX(s->map.world_h - 32);
    s->pl2.t.floor_y = s->pl.t.floor_y;

    s->coll.map = &s->map;
    s->coll.ts = s->tiles;
    s->coll.ents = s->ents;
    fa_player_set_ladder(&s->pl, slice_ladder, &s->map);
    fa_player_set_solid(&s->pl, slice_solid, &s->coll);
    fa_player_set_pushable(&s->pl, slice_pushable, s->ents);
    fa_player_set_ladder(&s->pl2, slice_ladder, &s->map);
    fa_player_set_solid(&s->pl2, slice_solid, &s->coll);
    fa_player_set_pushable(&s->pl2, slice_pushable, s->ents);
    /* boss arena: Pinguì idles only the yawn, Milchschnitte does not idle. */
    fa_player_set_boss_arena(&s->pl, s->in_end);
    fa_player_set_boss_arena(&s->pl2, s->in_end);
    if (s->ents)
        fa_entity_set_terrain(s->ents, slice_terrain, &s->coll);

    /* bind the per-ObjNr enemy behaviour layer over the entity store */
    fa_beh_free(s->beh);
    s->beh = NULL;
    s->freemove = 0;             /* DEV: always start a level clipped */
    s->death_player = 0;
    s->swap_was = s->jump_was = s->thr_was = s->glide_was = 0;
    s->idle_was = 0;
    s->push_was = 0;
    s->kid_was_crouch = s->kid_rise = 0;
    s->kid_was_crouch2 = s->kid_rise2 = 0;
    s->jump_was2 = s->thr_was2 = s->glide_was2 = s->push_was2 = 0;
    s->health = 100;             /* 0x45F014 init (0x4086fb) */
    s->ammo = 10;               /* 0x45ED34 init (0x4086f1) */
    s->dirty_shot = 0;
    memset(s->items, 0, sizeof s->items);
    fa_death_init(&s->death);    /* clear any in-flight death sequence */
    if (s->ents) {
        static const fa_beh_hooks HK = { beh_terrain, beh_score, beh_sfx,
                                         beh_voice, beh_voice_busy,
                                         beh_tutorial_done, NULL };
        fa_beh_hooks hk = HK;
        hk.user = s;
        s->beh = fa_beh_create(s->ents, &hk);
        fa_beh_seed(s->beh, s->rng_seed);   /* clock seed / --seed N */
        fa_beh_set_world(s->beh, s->world);
        fa_beh_set_character(s->beh, s->pl.character & 1);
    }
    set_world_ambient(s, s->world);
    apply_tuning(s);
    if (s->ov_camrail > 0) { s->cam.rail_l = s->ov_camrail;
                             s->cam.rail_r = FA_FB_W - s->ov_camrail; }
    if (s->ov_camband > 0) { int mid = (s->cam.band_t + s->cam.band_b) / 2;
                             s->cam.band_t = mid - s->ov_camband / 2;
                             s->cam.band_b = mid + s->ov_camband / 2; }
    if (s->ov_cambias != 0) { s->cam.band_t += s->ov_cambias;
                              s->cam.band_b += s->ov_cambias; }

    /* frame 0 camera: boss arenas fix the frame (world 3 keeps following),
     * regular levels point at the spawn (exe 0x4119c8). */
    if (s->in_end) fa_camera_boss(&s->cam, s->world);
    else fa_camera_intro(&s->cam, fa_player_px(&s->pl), fa_player_py(&s->pl));
}

/*
 * Kid animation clips from PINGUIN.W01 / MILCHSCHNITTE.W01. The per-pose frame
 * ranges are the exe state-machine constants; `loop` = 1 repeats, 0 holds the
 * last frame. Raw art is LEFT-facing (mirrored for right), advancing 1 frame
 * per 2 ticks (30 fps). The WESTKA sidecars disagree and are not used.
 */
typedef struct { fa_cs_pose pose; int cur, loop_first, end, loop; } kid_clip;

static const kid_clip PENGUIN_CLIPS[] = {
    { FA_CS_STAND,       47,  47,  47, 1 },  /* state 0/1  */
    { FA_CS_WALK,        75,  78,  87, 1 },  /* state 2/3  */
    { FA_CS_JUMP_RISE,    0,   0,   8, 0 },  /* state 4/5  */
    { FA_CS_JUMP_FALL,    8,   8,  14, 0 },  /* state 6/7  (rise 0..8 -> 9..14) */
    { FA_CS_CROUCH,     136, 136, 143, 0 },  /* state 8/9  down: hold at 143 */
    { FA_CS_CROUCH_RISE,144, 144, 149, 0 },  /* state 9 release: 144..149 once */
    { FA_CS_GLIDE,      287, 287, 287, 0 },  /* state 10/11 - a single frame */
    { FA_CS_CLIMB,      124, 124, 135, 1 },  /* state 12/13 */
    { FA_CS_THROW_FWD,  233, 233, 260, 0 },  /* state 14/15 snowball (spawn f255) */
    { FA_CS_THROW_UP,   233, 233, 260, 0 },  /* same range; only trajectory differs */
    { FA_CS_KO,         150, 158, 162, 1 },  /* state 34/35 */
    { FA_CS_IDLE_A,      65,  65,  69, 1 },  /* state 1 idle A - loops for the voice */
    { FA_CS_IDLE_B,      91,  91, 115, 0 },  /* state 1 idle B (yawn) - one pass */
    { FA_CS_SWAP,        65,  65,  69, 1 },  /* switch: loops 65-69 for the voice line */
    { FA_CS_SWAP_END,    65,  65,  69, 1 },  /* Pinguì has no turn-back */
};
static const kid_clip MILCH_CLIPS[] = {
    { FA_CS_STAND,        0,   0,   0, 1 },  /* state 16/17 */
    { FA_CS_WALK,         0,   3,  12, 1 },  /* state 18/19 */
    { FA_CS_JUMP_RISE,   56,  56,  58, 0 },  /* state 20/21 */
    { FA_CS_JUMP_FALL,   58,  58,  65, 0 },  /* state 22/23 */
    { FA_CS_CROUCH,     259, 259, 266, 0 },  /* state 24/25 down */
    { FA_CS_CROUCH_RISE,267, 267, 272, 0 },  /* state 25 release */
    /* no glide state for Milchschnitte - GLIDE stays unbound (falls back to FALL) */
    { FA_CS_CLIMB,       24,  24,  35, 1 },  /* state 28/29 */
    { FA_CS_PUSH,       172, 172, 190, 1 },  /* state 32/33 */
    { FA_CS_THROW_FWD,  273, 273, 296, 0 },  /* state 30/31 snowball (spawn f291) */
    { FA_CS_THROW_UP,   273, 273, 296, 0 },
    { FA_CS_KO,          36,  44,  48, 1 },  /* state 36/37 */
    { FA_CS_IDLE_B,     137, 146, 150, 1 },  /* state 17 idle: lead 137, loop 146-150 */
    { FA_CS_SWAP,       137, 146, 150, 1 },  /* switch: turn to camera, loop 146-150 */
    { FA_CS_SWAP_END,   150, 150, 159, 0 },  /* the 150-159 turn-back (swap + idle tail) */
};

static void bind_kid(fa_cs_anim *a, const kid_clip *t, int n)
{
    for (int i = 0; i < n; i++)
        fa_cs_anim_bind_frames(a, t[i].pose, t[i].cur, t[i].loop_first,
                               t[i].end, t[i].loop);
}

static void load_kids(slice *s)
{
    const char *w01[2] = { "Animation/PINGUIN.W01", "Animation/MILCHSCHNITTE.W01" };

    s->have_kids = 0;
    for (int k = 0; k < 2; k++) {
        char wp[700];
        snprintf(wp, sizeof wp, "%s/%s", s->gdata, w01[k]);
        if (fa_cs_sheet_open(&s->kid_sheet[k], wp, NULL, -1) != 0) {
            printf("character %d: no sprite sheet at %s (using a box)\n", k, wp);
            return;
        }
        fa_cs_anim_init(&s->kid_anim[k], &s->kid_sheet[k]);
        fa_cs_anim_set_period(&s->kid_anim[k], 2);   /* 30 fps */
    }
    bind_kid(&s->kid_anim[0], PENGUIN_CLIPS,
             (int)(sizeof PENGUIN_CLIPS / sizeof *PENGUIN_CLIPS));
    bind_kid(&s->kid_anim[1], MILCH_CLIPS,
             (int)(sizeof MILCH_CLIPS / sizeof *MILCH_CLIPS));
    s->have_kids = 1;
    printf("characters: Pinguì %d frames, Milchschnitte %d frames\n",
           fa_cs_sheet_frame_count(&s->kid_sheet[0]),
           fa_cs_sheet_frame_count(&s->kid_sheet[1]));
}

static void free_kids(slice *s)
{
    if (!s->have_kids) return;
    for (int k = 0; k < 2; k++) {
        fa_cs_anim_free(&s->kid_anim[k]);
        fa_cs_sheet_close(&s->kid_sheet[k]);
    }
    s->have_kids = 0;
}

/* Map the player state machine to a sprite pose. */
static fa_cs_pose kid_pose(const fa_player *p)
{
    if (p->throw_anim > 0) return FA_CS_THROW_FWD;   /* up-throw: exe follow-up */
    switch (p->state) {
    case FA_PST_STAND:
        if (p->idle_kind == 1) return FA_CS_IDLE_A;
        if (p->idle_kind == 2) return FA_CS_IDLE_B;
        return FA_CS_STAND;
    case FA_PST_WALK:   return FA_CS_WALK;
    case FA_PST_CROUCH: return FA_CS_CROUCH;
    case FA_PST_JUMP:   return FA_CS_JUMP_RISE;
    case FA_PST_FALL:   return p->gliding ? FA_CS_GLIDE : FA_CS_JUMP_FALL;
    case FA_PST_CLIMB:  return FA_CS_CLIMB;
    case FA_PST_PUSH:   return FA_CS_PUSH;
    case FA_PST_SWAP:   return FA_CS_SWAP;
    default:            return FA_CS_STAND;
    }
}

/* Publish both live player bodies to the enemy layer. Health, ammo and
 * pickups stay in `slice` and are not duplicated here. */
static void slice_beh_begin(slice *s)
{
    if (!s->beh) return;
    fa_beh_player p[2];
    memset(p, 0, sizeof p);
    p[0].active = 1;
    p[0].feet_x = fa_player_px(&s->pl);
    p[0].feet_y = fa_player_py(&s->pl);
    p[0].half_w = 40;
    p[0].height = s->pl.state == FA_PST_CROUCH ? 100 : 190;
    p[0].facing = s->pl.facing == FA_FACE_RIGHT ? 1 : -1;
    p[0].iframes = s->hurt_cd;
    p[0].character = s->pl.character & 1;
    p[0].ammo_dirty = s->dirty_shot;
    p[0].snow = s->pl.snow;
    p[0].snow_max = FA_MAX_SNOWBALLS;

    p[1].active = s->coop;
    p[1].feet_x = fa_player_px(&s->pl2);
    p[1].feet_y = fa_player_py(&s->pl2);
    p[1].half_w = 40;
    p[1].height = s->pl2.state == FA_PST_CROUCH ? 100 : 190;
    p[1].facing = s->pl2.facing == FA_FACE_RIGHT ? 1 : -1;
    p[1].iframes = s->hurt_cd;
    p[1].character = 1;
    p[1].ammo_dirty = s->dirty_shot;
    p[1].snow = s->pl2.snow;
    p[1].snow_max = FA_MAX_SNOWBALLS;
    fa_beh_set_character(s->beh, p[0].character);
    fa_beh_set_ammo_dirty(s->beh, s->dirty_shot);
    fa_beh_begin_players(s->beh, p, s->coop ? 2 : 1);
}

static void slice_update_kid_anim(slice *s, fa_player *p, int k,
                                  int *was_crouch, int *rise)
{
    fa_cs_pose pose = kid_pose(p);
    if (pose == FA_CS_SWAP && (p->character & 1) &&
        p->swap_timer <= p->t.swap_end_c1)
        pose = FA_CS_SWAP_END;
    /* Milchschnitte's idle ends with the same 150..159 turn-back as the swap once
     * the voice line stops (exe 0x418E0E): 10 frames * 2 ticks = 20. */
    if (pose == FA_CS_IDLE_B && (p->character & 1) &&
        p->idle_play > 0 && p->idle_play <= 20)
        pose = FA_CS_SWAP_END;
    int crouch = pose == FA_CS_CROUCH;
    if (*was_crouch && !crouch && p->on_ground) *rise = 14;
    *was_crouch = crouch;
    if (*rise > 0) { (*rise)--; pose = FA_CS_CROUCH_RISE; }
    fa_cs_anim_set_period(&s->kid_anim[k],
                          (p->state == FA_PST_CLIMB && !p->climb_moving)
                          ? 0 : 2);
    int face = p->facing;
    if (pose == FA_CS_CLIMB && s->kid_anim[k].sheet)
        face = -s->kid_anim[k].sheet->base_facing;
    fa_cs_anim_set(&s->kid_anim[k], pose, face);
    fa_cs_anim_tick(&s->kid_anim[k]);
}

/*
 * Has this world's tutorial been cleared? Reads byte world-1 of Save/tut.ini
 * (0 = show WeltNt). Missing file -> every tutorial shows.
 */
static int slice_tut_seen(const char *gdata, int world)
{
    fa_vfs v;
    if (fa_vfs_init_default(&v, gdata, "FreshAdventures") != 0) return 0;
    return fa_vfs_tut_world_seen(&v, world);
}

/* The .w01/.w02 suffix for a normal launch: "t" until tut.ini clears the
 * world, else "" (exe 0x411682). */
static const char *slice_world_suffix(const char *gdata, int world, int force_tut)
{
    return (force_tut || !slice_tut_seen(gdata, world)) ? "t" : "";
}

static void enter_world(slice *s, int world)
{
    slice_audio_hush(s);
    /* A new run starts in single-player; enter_end() keeps co-op alive. */
    s->coop = 0;
    s->p1_controller = -1;
    s->p2_controller = -1;
    s->keyboard_roles_swapped = 0;
    if (s->menu) { fa_menu_free(s->menu); s->menu = NULL; }
    const char *suf = slice_world_suffix(s->gdata, world, 0);
    if (load_world(s, s->gdata, world, suf, suf) == 0) {
        s->have_map = 1;
        s->use_player = 1;
        s->world = world;
        s->in_end = 0;
        s->end_pending = 0;
        s->boss_win_timer = 0;
        s->score = 0;               /* 0x41154C: a fresh run starts at 0 */
        if (s->audio && world >= 1 && world <= 4)
            fa_audio_event(s->audio, (fa_snd_event)(FA_SND_MUSIC_W1 + world - 1));
        fa_camera_init(&s->cam, FA_FB_W, FA_FB_H, s->map.world_w, s->map.world_h);
        wire_level(s);
        free_kids(s);
        load_kids(s);
        fa_hud_free(s->hud);
        s->hud = fa_hud_load(s->gdata);
        printf("hud: %s\n", s->hud ? "loaded" : "absent");
        printf("entered Welt%d%s%s: grid %dx%d, world %dx%d px\n", world,
               *suf ? suf : "", *suf ? " (tutorial - tut.ini byte 0)" : "",
               s->map.info.grid_w, s->map.info.grid_h,
               s->map.world_w, s->map.world_h);
    } else {
        printf("could not load Welt%d from %s\n", world, s->gdata);
        s->want_quit = 1;
    }
}

/*
 * The boss arena, gated on all six recipe pieces (exe 0x411365 -> state 20,
 * target level world + 4). WeltNE has no own .W01 and renders on WeltN.W01.
 */
static void enter_end(slice *s)
{
    slice_audio_hush(s);
    int world = s->world;
    if (load_world(s, s->gdata, world, "", "E") == 0) {
        s->have_map = 1;
        s->use_player = 1;
        s->in_end = 1;
        s->end_pending = 0;
        s->boss_win_timer = 0;
        if (s->audio) fa_audio_event(s->audio, FA_SND_MUSIC_BOSS);
        fa_camera_init(&s->cam, FA_FB_W, FA_FB_H, s->map.world_w, s->map.world_h);
        wire_level(s);
        free_kids(s);
        load_kids(s);
        fa_hud_free(s->hud);
        s->hud = fa_hud_load(s->gdata);
        printf("recipe complete -> Welt%dE (boss): world %dx%d px\n",
               world, s->map.world_w, s->map.world_h);
    } else {
        /* no boss map for this world: stay put, do not re-trigger */
        s->end_pending = 0;
        s->in_end = 1;
        printf("recipe complete but Welt%dE is absent - staying in Welt%d\n",
               world, world);
    }
}

/*
 * The run is over (health 0, KO hold + fade elapsed). Plays Start.wav and
 * shows the CLASSIFICA / high-score screen for the played world with the run
 * score, then the menu (exe 0x41272D). No restart, no lives.
 */
static void begin_after_death(slice *s, int won)
{
    slice_audio_hush(s);
    if (s->audio) fa_audio_event(s->audio, FA_SND_MENU_MUSIC);   /* Start.wav */

    fa_beh_free(s->beh);  s->beh = NULL;
    free_kids(s);
    fa_hud_free(s->hud);  s->hud = NULL;
    s->have_map = 0;
    s->use_player = 0;
    s->in_end = 0;
    s->end_pending = 0;
    s->boss_win_timer = 0;

    s->scores = fa_hiscore_load(s->gdata);
    if (s->scores) {
        /* show that world's table + boss portrait, and offer the run score:
         * it becomes an editable name row if it places. */
        fa_hiscore_begin(s->scores, s->world - 1, s->score, 1);
    } else {
        slice_set_menu(s, fa_menu_load(s->gdata));      /* no assets: menu */
    }

    fa_death_init(&s->death);
    printf("%s (score %d) -> CLASSIFICA (Welt%d), then the menu\n",
           won ? "World cleared - boss down" : "run over", s->score, s->world);
}

/* ESC / controller SELECT in a level: tear the level down and return to the
 * title / world-select menu. No score screen, no save. */
static void return_to_menu(slice *s)
{
    slice_audio_hush(s);
    if (s->audio) fa_audio_event(s->audio, FA_SND_MENU_MUSIC);

    fa_beh_free(s->beh);  s->beh = NULL;
    free_kids(s);
    fa_hud_free(s->hud);  s->hud = NULL;
    if (s->have_map) { fa_map_free(&s->map); fa_w01_close(&s->bg); }
    fa_tileset_free(s->tiles);  s->tiles = NULL;
    fa_entity_free(s->ents);    s->ents = NULL;
    s->have_map = 0;
    s->use_player = 0;
    s->in_end = 0;
    s->end_pending = 0;
    s->boss_win_timer = 0;
    s->coop = 0;
    s->p1_controller = -1;
    s->p2_controller = -1;
    s->keyboard_roles_swapped = 0;
    s->score = 0;
    fa_death_init(&s->death);

    slice_set_menu(s, fa_menu_load(s->gdata));
    printf("ESC / SELECT -> the menu\n");
}

static int s_quit(void *user) { return ((slice *)user)->want_quit; }

/* Find the closest world icon in a screen direction, using the menu's own
 * pixel rectangles rather than a second hand-written layout. */
static int menu_next_world(const fa_menu *m, int current, int dx, int dy)
{
    int ox = 400, oy = 300;
    if (current >= 0 && current < 4) {
        int x, y, w, h;
        if (fa_menu_hit_rect(m, current, &x, &y, &w, &h) == 0) {
            ox = x + w / 2;
            oy = y + h / 2;
        }
    }

    int best = -1, best_score = 0x7fffffff;
    for (int i = 0; i < 4; i++) {
        if (i == current) continue;
        int x, y, w, h;
        if (fa_menu_hit_rect(m, i, &x, &y, &w, &h) != 0) continue;
        int vx = x + w / 2 - ox;
        int vy = y + h / 2 - oy;
        int primary = dx ? vx * dx : vy * dy;
        if (primary <= 0) continue;
        int secondary = dx ? abs(vy) : abs(vx);
        int distance = vx * vx + vy * vy;
        int score = primary * 10000 + secondary * 100 + distance;
        if (score < best_score) {
            best_score = score;
            best = i;
        }
    }
    return best;
}

static int menu_move_focus(slice *s, const fa_frame_input *fi)
{
    uint32_t keys = fi->actions_pressed;
    uint32_t pad  = fi->pad_pressed;
    uint32_t nav_edges = keys & ((1u << FA_ACT_LEFT) | (1u << FA_ACT_RIGHT) |
                                 (1u << FA_ACT_UP) | (1u << FA_ACT_DOWN));
    nav_edges |= pad & ((1u << FA_PAD_DPAD_LEFT) | (1u << FA_PAD_DPAD_RIGHT) |
                        (1u << FA_PAD_DPAD_UP) | (1u << FA_PAD_DPAD_DOWN));
    uint32_t fresh_edges = nav_edges & ~s->menu_nav_seen;
    s->menu_nav_seen = nav_edges;
    if (!nav_edges) s->menu_nav_seen = 0;
    if (!fresh_edges) return 0;

    int dx = 0, dy = 0;

    if (fresh_edges & ((1u << FA_ACT_LEFT) | (1u << FA_PAD_DPAD_LEFT)))
        dx = -1;
    else if (fresh_edges & ((1u << FA_ACT_RIGHT) | (1u << FA_PAD_DPAD_RIGHT)))
        dx = 1;
    else if (fresh_edges & ((1u << FA_ACT_UP) | (1u << FA_PAD_DPAD_UP)))
        dy = -1;
    else if (fresh_edges & ((1u << FA_ACT_DOWN) | (1u << FA_PAD_DPAD_DOWN)))
        dy = 1;

    int had_focus = s->menu_focus >= 0 && s->menu_focus < 4;
    int current = had_focus ? s->menu_focus : 0;
    int next = menu_next_world(s->menu, current, dx, dy);
    if (next < 0 && !had_focus) next = 0;
    if (next < 0) return 0;
    s->menu_focus = next;
    return 1;
}

/* Carry a rider horizontally by `dx` whole px, stopping at walls the same
 * way its own step would - the exe sweeps the lift carry through 0x432160. */
static void slice_lift_carry_x(fa_player *p, int dx)
{
    if (dx == 0) return;
    fa_aabb_body bd;
    memset(&bd, 0, sizeof bd);
    bd.x  = p->x;
    bd.y  = p->y;
    bd.vx = FA_FIX(dx);
    bd.hw = p->t.body_hw > 0 ? p->t.body_hw : 1;
    bd.h  = p->t.body_h  > 0 ? p->t.body_h  : 1;
    fa_collide_move(&bd, 0, p->solid_fn, p->solid_ctx);
    p->x = bd.x;
}

static void s_sim(uint64_t tick, const void *input, void *user)
{
    slice *s = (slice *)user;
    const fa_frame_input *fi = (const fa_frame_input *)input;
    uint32_t m = fi->actions;
    slice_merge_pad_movement(fi, &m);
    (void)tick;

    if (s->pending_world) {
        int wd = s->pending_world;
        s->pending_world = 0;
        enter_world(s, wd);
        return;
    }
    if (s->end_pending) { enter_end(s); return; }

    /* tutorial cleared: reload the same world as the normal level, keeping
     * the score across the reload (exe 0x4126F3). */
    if (s->tut_reload_pending) {
        s->tut_reload_pending = 0;
        int wd = s->world, sc = s->score;
        enter_world(s, wd);
        s->score = sc;
        return;
    }

    /* credits screen: Credit1..4.bmp, then ENDTITLES, then the menu. A page
     * auto-advances; a click or JUMP/FIRE press skips to the next at once. */
    if (s->credits) {
        uint32_t act = fi->actions;
        uint32_t press = act & ~s->cr_act_was;
        s->cr_act_was = act;
        int skip = (fi->btn_pressed & 1u) != 0 ||
                   (press & ((1u << FA_ACT_JUMP) | (1u << FA_ACT_FIRE))) != 0;
        fa_credits_tick(s->credits, skip);
        if (fa_credits_done(s->credits)) {
            fa_credits_free(s->credits);
            s->credits = NULL;
            slice_set_menu(s, fa_menu_load(s->gdata));
            slice_audio_hush(s);
            if (s->audio) fa_audio_event(s->audio, FA_SND_MENU_MUSIC);
            printf("credits done -> the menu\n");
        }
        return;
    }

    /* CLASSIFICA / high-score screen, from the menu button or after a death.
     * A click returns to the menu, rebuilding it and zeroing the score if a
     * death tore it down (exe 0x41154C). */
    if (s->show_scores && !s->scores) {
        s->scores = fa_hiscore_load(s->gdata);
        s->show_scores = 0;
        if (s->scores)                       /* from the menu: plain view */
            fa_hiscore_begin(s->scores, 0, -1, 0);
    }
    if (s->scores) {
        fa_hiscore_in hi;
        memset(&hi, 0, sizeof hi);
        hi.ptr_x     = fi->ptr_x;
        hi.ptr_y     = fi->ptr_y;
        hi.click     = (fi->btn_pressed & 1u) != 0;
        hi.text      = (const char *)fi->text;
        hi.text_n    = fi->text_n;
        hi.backspace = (fi->edit_pressed & FA_EDIT_BACKSPACE) != 0;
        hi.enter     = (fi->edit_pressed & FA_EDIT_ENTER) != 0;
        hi.escape    = (fi->edit_pressed & FA_EDIT_ESCAPE) != 0;

        fa_hiscore_ev he;
        fa_hiscore_tick(s->scores, &hi, &he);

        if (he.hover_sound && s->audio)
            fa_audio_event(s->audio, FA_SND_MENU_HOVER);   /* alsf08 */

        if (he.wrote)   /* fa_hiscore persisted user:Highscore{n}.dat */
            printf("high score entered -> Highscore%d.dat\n", he.wrote_world + 1);

        if (he.leave) {
            fa_hiscore_free(s->scores);
            s->scores = NULL;
            if (!s->menu) {                  /* came from a death */
                slice_set_menu(s, fa_menu_load(s->gdata));
                s->score = 0;
            } else {
                slice_focus_first_menu(s);
            }
        }
        return;
    }

    if (s->menu) {
        int navigated = menu_move_focus(s, fi);
        int pick = fa_menu_pick(s->menu, fi->ptr_x, fi->ptr_y);
        int mouse_click = (fi->btn_pressed & 1u) != 0;
        if (!navigated && fi->ptr_moved) s->menu_focus = pick;
        if (mouse_click && pick >= 0) s->menu_focus = pick;
        int focus = s->menu_focus >= 0 ? s->menu_focus : pick;
        int held = (fi->btn_down & 1u) != 0 ||
                   (fi->pad_down & (1u << FA_PAD_A)) != 0;
        for (int i = 0; i < fa_menu_button_count(s->menu); i++)
            fa_menu_set_state(s->menu, i,
                i == focus ? (held ? FA_MENU_PRESS : FA_MENU_HOVER)
                          : FA_MENU_REST);
        if (s->audio && focus >= 0 && focus != s->hover)
            fa_audio_event(s->audio, FA_SND_MENU_HOVER);   /* alsf08 */
        s->hover = focus;
        int confirm = (mouse_click && pick >= 0) ||
                      (fi->pad_pressed & (1u << FA_PAD_A)) != 0 ||
                      (fi->edit_pressed & FA_EDIT_ENTER) != 0;
        if (focus >= 0 && confirm) {
            if (focus <= 3)       s->pending_world = focus + 1; /* GIUNGLA=1 */
            else if (focus == 4)  s->show_scores = 1;            /* CLASSIFICA */
            else if (focus == 5)  s->want_quit = 1;              /* ESCI */
        }
        return;
    }

    if (s->use_player) {
        if ((fi->edit_pressed & FA_EDIT_ESCAPE) ||
            (fi->pad_pressed & (1u << FA_PAD_BACK))) {
            return_to_menu(s);
            return;
        }
        if (slice_join_coop(s, fi)) {
            /* consume the join edge; movement starts next tick so the press
             * is not an accidental jump/throw. */
            return;
        }
        m = slice_player_actions(s, fi, 0);
        uint32_t m2 = slice_player_actions(s, fi, 1);
        if (s->coop) {
            int teleport = 0;
            if (s->p2_controller >= 0 && s->p2_controller < FA_APP_MAX_PADS)
                teleport = (fi->pads[s->p2_controller].pressed &
                            (1u << FA_PAD_LEFTSHOULDER)) != 0;
            else
                teleport = fi->keyboard2_teleport_pressed != 0;
            if (teleport) slice_teleport_milch(s);
        }

        /* DEV: P toggles no-clip fly. Pickups, camera and the boss gate still
         * run; gravity, terrain, lifts and enemy damage are bypassed. */
        if (fi->dbg_pressed & FA_DBG_FREEMOVE) {
            s->freemove = !s->freemove;
            printf("free-move %s\n", s->freemove ? "ON" : "OFF");
        }

        /* DEV: I skips straight to this world's boss arena. */
        if ((fi->dbg_pressed & FA_DBG_BOSS) && !s->coop &&
            !s->in_end && !s->end_pending &&
            s->world >= 1 && s->world <= 4) {
            for (int i = 0; i < 6; i++) s->items[i] = 1;   /* recipe "complete" */
            s->end_pending = 1;
            printf("skip -> Welt%dE boss arena\n", s->world);
        }

        /* the character is dead. The level keeps running through the KO hold + fade
         * (exe 0x41110B), then begin_after_death. Input is locked; the body
         * runs physics so it arcs down and lands, render forces the KO pose. */
        if (fa_death_phase_of(&s->death) != FA_DEATH_ALIVE) {
            fa_death_tick(&s->death);
            if (fa_death_phase_of(&s->death) == FA_DEATH_DONE) {
                begin_after_death(s, 0);
                return;
            }
            slice_beh_begin(s);
            if (s->ents)
                fa_entity_tick(s->ents, s->cam.x, s->cam.y, FA_FB_W, FA_FB_H);
            if (s->beh) { int kb = 0; (void)fa_beh_post(s->beh, &kb); }
            slice_posloops(s);
            fa_player_tick(&s->pl, 0);          /* no input; body settles */
            if (s->coop) fa_player_tick(&s->pl2, 0);
            fa_camera_follow(&s->cam, fa_player_px(&s->pl), fa_player_py(&s->pl),
                             s->pl.facing == FA_FACE_RIGHT ? 0 : 1);
            if (s->have_kids) {
                fa_player *dead = s->death_player ? &s->pl2 : &s->pl;
                int k = s->death_player ? 1 : (s->pl.character & 1);
                fa_cs_anim_set_period(&s->kid_anim[k], 2);
                fa_cs_anim_set(&s->kid_anim[k], FA_CS_KO, dead->facing);
                fa_cs_anim_tick(&s->kid_anim[k]);
                if (s->coop) {
                    fa_player *other = s->death_player ? &s->pl : &s->pl2;
                    int ok = s->death_player ? (s->pl.character & 1) : 1;
                    slice_update_kid_anim(s, other, ok,
                                          s->death_player ? &s->kid_was_crouch
                                                          : &s->kid_was_crouch2,
                                          s->death_player ? &s->kid_rise
                                                          : &s->kid_rise2);
                }
            }
            return;
        }

        /* boss down, 7th recipe piece caught (fa_beh beh_i7): level complete,
         * go to the CLASSIFICA screen. */
        if (s->in_end && s->beh && fa_beh_recipe_done(s->beh)) {
            if (s->audio) fa_audio_event(s->audio, FA_SND_PICKUP);
            printf("World %d complete (score %d) -> CLASSIFICA\n",
                   s->world, s->score);
            begin_after_death(s, 1);
            return;
        }

        /* tick the object runtime FIRST so the player's collision probe sees
         * lifts / blocks / fallers at their new positions this tick. */
        slice_beh_begin(s);
        if (s->ents)
            fa_entity_tick(s->ents, s->cam.x, s->cam.y, FA_FB_W, FA_FB_H);

        /* PRE-tick: if the character rides a platform, plant its feet on the moved
         * deck so fa_player_tick grounds it this tick; otherwise crouch /
         * throw fail while the platform moves. */
        int on_lift = 0, lift_top = 0, lift_dx = 0;
        int on_lift2 = 0, lift_top2 = 0, lift_dx2 = 0;
        if (!s->freemove && s->ents && s->pl.vy >= 0 && s->pl.state != FA_PST_JUMP) {
            int cdy = 0;
            if (fa_entity_ride(s->ents, fa_player_px(&s->pl),
                               fa_player_py(&s->pl), s->pl.t.body_hw,
                               &lift_top, &lift_dx, &cdy)) {
                on_lift = 1;
                s->pl.y = FA_FIX(lift_top);
                s->pl.vy = 0;
                s->pl.on_ground = 1;
            }
        }
        if (s->coop && !s->freemove && s->ents && s->pl2.vy >= 0 &&
            s->pl2.state != FA_PST_JUMP) {
            int cdy = 0;
            if (fa_entity_ride(s->ents, fa_player_px(&s->pl2),
                               fa_player_py(&s->pl2), s->pl2.t.body_hw,
                               &lift_top2, &lift_dx2, &cdy)) {
                on_lift2 = 1;
                s->pl2.y = FA_FIX(lift_top2);
                s->pl2.vy = 0;
                s->pl2.on_ground = 1;
            }
        }

        int shot0_reserved = 0;
        if (s->freemove) {
            /* direct fly: arrows move, hold A for a fast dash. No physics. */
            int spd = (m & (1u << FA_ACT_JUMP)) ? 12 : 6;
            int dx = 0, dy = 0;
            if (m & (1u << FA_ACT_LEFT))  dx -= spd;
            if (m & (1u << FA_ACT_RIGHT)) dx += spd;
            if (m & (1u << FA_ACT_UP))    dy -= spd;
            if (m & (1u << FA_ACT_DOWN))  dy += spd;
            s->pl.x += FA_FIX(dx);
            s->pl.y += FA_FIX(dy);
            if (dx) s->pl.facing = (dx < 0) ? FA_FACE_LEFT : FA_FACE_RIGHT;
            s->pl.vx = s->pl.vy = 0;
            s->pl.on_ground = 1;
            s->pl.gliding = s->pl.throw_anim = 0;
            s->pl.state = (dx || dy) ? FA_PST_WALK : FA_PST_STAND;
            if (s->pl.x < 0) s->pl.x = 0;
            if (s->pl.y < FA_FIX(16)) s->pl.y = FA_FIX(16);
            if (s->pl.x > FA_FIX(s->map.world_w)) s->pl.x = FA_FIX(s->map.world_w);
            if (s->pl.y > FA_FIX(s->map.world_h)) s->pl.y = FA_FIX(s->map.world_h);
        } else {
            if (s->ammo <= 0) m &= ~(1u << FA_ACT_FIRE);   /* AC4: no snowballs */
            fa_player_tick(&s->pl, m);   /* FA_PI_* == (1u<<FA_ACT_*) */
            /* Reserve Pinguì's shared ammo before ticking player 2, so two
             * simultaneous fire presses cannot consume one final snowball
             * twice. */
            if (s->ammo > 0 && s->pl.throw_anim > 0 && !s->thr_was) {
                s->ammo--;
                shot0_reserved = 1;
            }
        }
        if (s->coop) {
            /* Milchschnitte keeps character-1 rules: lower jump, no glide. */
            if (s->freemove) {
                int spd2 = (m2 & (1u << FA_ACT_JUMP)) ? 12 : 6;
                int dx2 = 0, dy2 = 0;
                if (m2 & (1u << FA_ACT_LEFT))  dx2 -= spd2;
                if (m2 & (1u << FA_ACT_RIGHT)) dx2 += spd2;
                if (m2 & (1u << FA_ACT_UP))    dy2 -= spd2;
                if (m2 & (1u << FA_ACT_DOWN))  dy2 += spd2;
                s->pl2.x += FA_FIX(dx2);
                s->pl2.y += FA_FIX(dy2);
                if (dx2) s->pl2.facing = dx2 < 0 ? FA_FACE_LEFT : FA_FACE_RIGHT;
                s->pl2.vx = s->pl2.vy = 0;
                s->pl2.on_ground = 1;
                s->pl2.gliding = s->pl2.throw_anim = 0;
                s->pl2.state = (dx2 || dy2) ? FA_PST_WALK : FA_PST_STAND;
            } else {
                if (s->ammo <= 0) m2 &= ~(1u << FA_ACT_FIRE);
                fa_player_tick(&s->pl2, m2);
            }
            /* co-op: only player 1 plays idle fidgets. */
            s->pl2.idle_kind = s->pl2.idle_play = s->pl2.idle_sound = 0;
            s->pl2.idle_timer = s->pl2.t.idle_delay;
        }
        /* the swap voice line starts with the swap; the lock lasts its length. */
        int swap_now  = (s->pl.state == FA_PST_SWAP);
        int jump_now  = (s->pl.state == FA_PST_JUMP);
        int thr_now   = (s->pl.throw_anim > 0);
        int glide_now = (s->pl.gliding != 0);       /* Pinguì only */
        int jump_now2 = s->coop && (s->pl2.state == FA_PST_JUMP);
        int thr_now2  = s->coop && (s->pl2.throw_anim > 0);
        int glide_now2 = s->coop && (s->pl2.gliding != 0);
        int c1 = s->pl.character & 1;
        if (s->audio) {
            if (!s->coop && swap_now && !s->swap_was)
                fa_audio_event(s->audio, c1 == 0 ? FA_SND_SWAP_P2M
                                                 : FA_SND_SWAP_M2P);
            /* alsf01 only on a real jump (jump_hold set): a knockback also
             * enters JUMP state but the hit sound owns that moment. */
            if (jump_now && !s->jump_was && s->pl.jump_hold > 0)
                fa_audio_event(s->audio, c1 ? FA_SND_JUMP_M : FA_SND_JUMP_P);
            if (thr_now && !s->thr_was)
                fa_audio_event(s->audio, c1 ? FA_SND_THROW_M : FA_SND_THROW_P);
            if (s->coop && jump_now2 && !s->jump_was2 && s->pl2.jump_hold > 0)
                fa_audio_event(s->audio, FA_SND_JUMP_M);
            if (s->coop && thr_now2 && !s->thr_was2)
                fa_audio_event(s->audio, FA_SND_THROW_M);
            if (glide_now && !s->glide_was)         /* alsf02, glide entry */
                fa_audio_event(s->audio, FA_SND_GLIDE);
            if (!glide_now && s->glide_was)         /* exe stops lane 0 on */
                fa_audio_stop(s->audio, 0);         /* glide exit: 0x422e04(0) */
            /* idle voice line on the idle_kind rising edge, player 1 only.
             * idle_sound picks the A1/A2 (or 1/2) variant; idle B is the yawn. */
            if (s->pl.idle_kind && !s->idle_was) {
                fa_snd_event ev = FA_SND_NONE;
                if (!c1)
                    ev = s->pl.idle_kind == 1
                           ? (s->pl.idle_sound ? FA_SND_PENGUIN_IDLE_A2
                                               : FA_SND_PENGUIN_IDLE_A1)
                           : FA_SND_PENGUIN_IDLE_B;
                else
                    ev = s->pl.idle_sound ? FA_SND_MILCH_IDLE_2
                                          : FA_SND_MILCH_IDLE_1;
                if (ev != FA_SND_NONE) fa_audio_event(s->audio, ev);
            }
        }
        if (thr_now && !s->thr_was && !shot0_reserved && s->ammo > 0)
            s->ammo--;
        if (s->coop && thr_now2 && !s->thr_was2 && s->ammo > 0) s->ammo--;
        s->swap_was  = swap_now;
        s->idle_was  = s->pl.idle_kind;
        s->jump_was  = jump_now;
        s->thr_was   = thr_now;
        s->glide_was = glide_now;
        s->jump_was2 = jump_now2;
        s->thr_was2  = thr_now2;
        s->glide_was2 = glide_now2;

        /* --- player <-> object coupling --- */
        if (s->ents) {
            int px = fa_player_px(&s->pl), py = fa_player_py(&s->pl);
            int face = (s->pl.facing == FA_FACE_RIGHT) ? 1 : -1;
            int px2 = fa_player_px(&s->pl2), py2 = fa_player_py(&s->pl2);
            int face2 = (s->pl2.facing == FA_FACE_RIGHT) ? 1 : -1;

            /* pickup / hit test uses the full-sprite AABB (half_w 40, height
             * 190 / crouch 100) plus an overhead reach, not the ~44 px
             * collision core - items sit in tree-tops and along the vines. */
            int pfull = (s->pl.state == FA_PST_CROUCH) ? 100 : 190;
            int gw  = 40;
            int gcy = py - pfull / 2;
            int gh  = pfull / 2 + 10;                    /* +10 overhead reach */

            /* Milchschnitte shoving a block: on the frame-176 event (~tick 8)
             * one impulse sets the block vx to +/-7.0 and beh_block slides it.
             * The character does not ride the block; each shove is a fresh approach. */
            if (s->pl.state == FA_PST_PUSH && s->beh) {
                int probx = px + face * (s->pl.t.body_hw + 8);
                if (s->pl.push_timer == 8 &&
                    fa_beh_push(s->beh, probx, py - 100, face) && s->audio)
                    fa_audio_event(s->audio, FA_SND_PUSH);   /* sound id 6 */
            }
            if (s->coop && s->pl2.state == FA_PST_PUSH && s->beh) {
                int probx = px2 + face2 * (s->pl2.t.body_hw + 8);
                if (s->pl2.push_timer == 8 &&
                    fa_beh_push(s->beh, probx, py2 - 100, face2) && s->audio)
                    fa_audio_event(s->audio, FA_SND_PUSH);
            }

            /* POST-tick: carry the platform's horizontal drift and re-plant
             * the feet, preserving the action state. Skipped once the character
             * jumps off. */
            if (on_lift && s->pl.state != FA_PST_JUMP) {
                slice_lift_carry_x(&s->pl, lift_dx);
                s->pl.y  = FA_FIX(lift_top);
                if (s->pl.vy > 0) s->pl.vy = 0;
                s->pl.on_ground = 1;
                if (s->pl.state == FA_PST_FALL)
                    s->pl.state = (s->pl.vx != 0) ? FA_PST_WALK : FA_PST_STAND;
            }
            if (s->coop && on_lift2 && s->pl2.state != FA_PST_JUMP) {
                slice_lift_carry_x(&s->pl2, lift_dx2);
                s->pl2.y  = FA_FIX(lift_top2);
                if (s->pl2.vy > 0) s->pl2.vy = 0;
                s->pl2.on_ground = 1;
                if (s->pl2.state == FA_PST_FALL)
                    s->pl2.state = (s->pl2.vx != 0) ? FA_PST_WALK : FA_PST_STAND;
            }

            /* collect BONUS / POWERUP pickups */
            int got = fa_entity_collect(s->ents, px, gcy, gw, gh, beh_pickup, s);
            if (s->coop) {
                int pfull2 = (s->pl2.state == FA_PST_CROUCH) ? 100 : 190;
                int gw2 = 40;
                int gcy2 = py2 - pfull2 / 2;
                int gh2 = pfull2 / 2 + 10;
                got += fa_entity_collect(s->ents, px2, gcy2, gw2, gh2,
                                         beh_pickup, s);
            }
            if (got) {
                if (s->audio) fa_audio_event(s->audio, FA_SND_PICKUP);
                printf("pickup x%d (score %d health %d ammo %d)\n",
                       got, s->score, s->health, s->ammo);
                /* AC4/boss gate (exe 0x411365): all 6 recipe pieces -> WeltNE */
                if (!s->in_end && s->world >= 1 && s->world <= 4) {
                    int all = 1;
                    for (int i = 0; i < 6; i++) if (!s->items[i]) { all = 0; break; }
                    if (all) s->end_pending = 1;
                }
            }

            /* enemy contact + projectiles. No stomp: any overlap is 20 damage
             * (exe 0x41A3E0 ignores vy), suppressed only by the i-frames. */
            int kb = 0;
            int dmg = s->beh ? fa_beh_post(s->beh, &kb) : 0;
            (void)kb;
            slice_posloops(s);
            if (dmg && s->hurt_cd == 0 && !s->freemove) {
                int hit_player = fa_beh_damage_player(s->beh, 0) ? 0 : 1;
                s->health -= dmg;
                s->hurt_cd = 120;              /* 0x41A538: 0x78 ticks */
                if (fa_beh_knockback_player(s->beh, hit_player)) {
                    fa_player *hit = hit_player ? &s->pl2 : &s->pl;
                    hit->vy = -FA_FIX(6);
                    hit->on_ground = 0;
                }
                s->death_player = hit_player;
                if (s->audio) {
                    /* the hit sound follows the CHARACTER, not the pad slot:
                     * Milchschnitte -> ms0007, Pinguì -> pi0005. */
                    int ms = hit_player ? 1 : (s->pl.character & 1);
                    fa_audio_event(s->audio, ms
                                   ? FA_SND_HIT_M : FA_SND_HIT_P);
                }
                printf("hit! health %d\n", s->health);
            }

            /* standing on a plane-2 hazard tile (exe fcn.0041A290): 20 damage
             * + 120 i-frames + hit sound when not already invulnerable, and
             * always a vy = -20.0 bounce so the character cannot sit in it. */
            int hazard0 = !s->freemove &&
                slice_hazard(&s->map, fa_player_px(&s->pl),
                             fa_player_py(&s->pl));
            int hazard1 = s->coop && !s->freemove &&
                slice_hazard(&s->map, fa_player_px(&s->pl2),
                             fa_player_py(&s->pl2));
            if ((hazard0 || hazard1) && s->health > 0) {
                if (s->hurt_cd == 0) {
                    s->health -= 20;
                    s->hurt_cd = 120;
                    s->death_player = hazard0 ? 0 : 1;
                    if (s->audio) {
                        int ms = hazard0 ? (s->pl.character & 1) : 1;
                        fa_audio_event(s->audio, ms
                                       ? FA_SND_HIT_M : FA_SND_HIT_P);
                    }
                    printf("hazard! health %d\n", s->health);
                }
                if (hazard0) {
                    s->pl.vy = -FA_FIX(20);
                    s->pl.on_ground = 0;
                }
                if (hazard1) {
                    s->pl2.vy = -FA_FIX(20);
                    s->pl2.on_ground = 0;
                }
            }
            if (s->hurt_cd > 0) s->hurt_cd--;

            /* boss down: its 7th recipe piece drops in (fa_beh beh_i7). */
            if (s->in_end && s->beh && fa_beh_boss_defeated(s->beh) &&
                !s->boss_win_timer) {
                s->boss_win_timer = 1;          /* one-shot: log it once */
                printf("boss defeated in Welt%dE (score %d) - catch the "
                       "7th recipe piece\n", s->world, s->score);
            }

            /* health 0: start the KO sequence (exe 0x417419). Launch the body
             * once (vx +/-18, vy -6); the integrator then arcs and lands it.
             * The fa_death branch above takes over from the next tick. */
            if (s->health <= 0 && !fa_death_active(&s->death) && !s->freemove) {
                fa_player *dead = s->death_player ? &s->pl2 : &s->pl;
                int face = dead->character & 1 ? 1 : -1;   /* 0x4E1020 sign */
                s->health = 0;
                dead->vx = FA_FIX(18) * face;
                dead->vy = -FA_FIX(6);
                dead->on_ground = 0;
                fa_death_begin(&s->death, dead->character & 1,
                               dead->facing == FA_FACE_RIGHT ? 1 : -1);
                printf("run over in Welt%d%s (score %d) -> KO %d t, fade %d t, "
                       "then CLASSIFICA\n", s->world, s->in_end ? "E" : "",
                       s->score, FA_DEATH_HOLD_TICKS, FA_DEATH_FADE_TICKS);
            }
        }

        fa_camera_follow(&s->cam, fa_player_px(&s->pl), fa_player_py(&s->pl),
                         s->pl.facing == FA_FACE_RIGHT ? 0 : 1);
        if (s->have_kids) {
            slice_update_kid_anim(s, &s->pl, s->pl.character & 1,
                                  &s->kid_was_crouch, &s->kid_rise);
            if (s->coop)
                slice_update_kid_anim(s, &s->pl2, 1,
                                      &s->kid_was_crouch2, &s->kid_rise2);
        }
        return;
    }
    int vx = 0, vy = 0;
    if (m & (1u << FA_ACT_LEFT))  vx -= 4;
    if (m & (1u << FA_ACT_RIGHT)) vx += 4;
    if (m & (1u << FA_ACT_UP))    vy -= 4;
    if (m & (1u << FA_ACT_DOWN))  vy += 4;
    if (s->have_map) fa_camera_move(&s->cam, vx, vy);
    else { s->cam.x += vx; s->cam.y += vy; }
}

/* The character + thrown snowballs draw as the plane-2 hook (exe 0x41A780), after
 * plane-2 tiles / band-0 entities but before band-2 entities and planes 3/4,
 * so jungle spikes and factory pipes pass in front of the character. Projectiles,
 * HUD and the death fade stay on top. */
static void slice_draw_player(slice *s, const fa_surface *dst,
                              const fa_camera *cam, const fa_player *p,
                              int k, int blink)
{
    int px = fa_player_px(p) - cam->x;
    int py = fa_player_py(p) - cam->y;
    long drawn = -1;
    /* blink the character through the i-frame window, but not while dying. */
    if (s->have_kids && !blink)
        drawn = fa_cs_anim_draw(&s->kid_anim[k], dst, px, py, NULL);
    else if (blink)
        drawn = 0;
    if (drawn < 0) {
        fa_rect body = { px - 8, py - 40, 16, 40 };
        fa_fill(dst, &body, NULL, fa_rgb565(240, 210, 60));
    }
}

static void slice_plane_hook(void *ud, const fa_surface *dst,
                             const fa_camera *cam, int plane)
{
    if (plane != 2) return;
    slice *s = (slice *)ud;
    if (!s->use_player) return;

    int blink = s->hurt_cd > 0 && !fa_death_active(&s->death) &&
                ((s->hurt_cd >> 2) & 1);
    slice_draw_player(s, dst, cam, &s->pl, s->pl.character & 1, blink);
    if (s->coop)
        slice_draw_player(s, dst, cam, &s->pl2, 1, blink);

    /* thrown snowball = PINGUIN.W01 frame 261; the "dirty" ball after
     * collect_dirtyballs is frame 232 (exe spawn 0x41A268). */
    const fa_w01 *proj_w = s->have_kids ? &s->kid_sheet[0].w01 : NULL;
    int proj_f = s->dirty_shot ? 232 : 261;
    const fa_player *players[2] = { &s->pl, &s->pl2 };
    for (int j = 0; j < (s->coop ? 2 : 1); j++) {
        for (int i = 0; i < FA_MAX_SNOWBALLS; i++) {
            if (!players[j]->snow[i].alive) continue;
            int sx = (int)(players[j]->snow[i].x >> 16) - cam->x;
            int sy = (int)(players[j]->snow[i].y >> 16) - cam->y;
            if (!blit_w01_centered(dst, proj_w, proj_f, sx, sy)) {
                fa_rect b = { sx - 3, sy - 3, 6, 6 };
                fa_fill(dst, &b, NULL,
                        s->dirty_shot ? fa_rgb565(40, 40, 48)
                                      : fa_rgb565(255, 255, 255));
            }
        }
    }
}

static void s_render(double alpha, uint16_t *fb, int w, int h, size_t pitch,
                     void *user)
{
    slice *s = (slice *)user;
    (void)alpha;
    fa_surface dst;
    fa_surface_wrap(&dst, fb, w, h, pitch);

    if (s->credits) {
        fa_credits_render(s->credits, &dst);
        return;
    }

    if (s->scores) {
        fa_hiscore_render(s->scores, &dst);
        return;
    }

    if (s->menu) {
        fa_menu_render(s->menu, &dst);   /* hover / pressed art is the feedback */
        return;
    }

    if (s->have_map) {
        fa_scene sc = { &s->bg, &s->map, s->tiles, s->ents, s->grid, NULL, NULL };
        sc.on_plane = slice_plane_hook;   /* character + snowballs at plane 2 */
        sc.on_plane_ud = s;
        fa_render_scene(&dst, &sc, &s->cam);
        if (s->use_player) {
            /* enemy projectiles render from the thrower's own sheet at a
             * per-ObjNr frame (exe 0x40AF80). */
            for (int i = 0; s->beh && i < FA_BEH_PROJ_MAX; i++) {
                int wx, wy, oo = 0;
                if (!fa_beh_projectile(s->beh, i, &wx, &wy, &oo)) continue;
                int sx = wx - s->cam.x, sy = wy - s->cam.y;
                int pf;
                switch (oo) {
                    case 5:  pf = 16; break;
                    case 7:  pf = 25; break;
                    case 8:  pf = 54; break;
                    case 12: pf = 23; break;
                    case 15: pf = 53; break;
                    case 10: pf = 87; break;
                    case 14: pf = 188; break;   /* robot boss bolt */
                    case 18: pf = 50; break;    /* octopus milk particle */
                    default: pf = -1; break;
                }
                const fa_w01 *pw = (pf >= 0 && s->ents)
                                 ? fa_entity_obj_sheet(s->ents, oo) : NULL;
                if (!pw || !blit_w01_centered(&dst, pw, pf, sx, sy)) {
                    fa_rect b = { sx - 4, sy - 4, 8, 8 };
                    fa_fill(&dst, &b, NULL, fa_rgb565(150, 90, 40));
                }
            }
            /* status panel. In the boss arena (exe 0x408B9B) the boss bar
             * replaces the 6 recipe icons; boss_hp = -1 keeps the normal HUD. */
            int boss_hp = (s->in_end && s->beh) ? fa_beh_boss_hp(s->beh) : -1;
            if (s->hud)
                fa_hud_render(s->hud, &dst, s->score, s->health, s->ammo,
                              s->dirty_shot, s->items,
                              s->coop ? 0 : s->pl.character,
                              boss_hp, s->world - 1);

            /* end-of-run fade: a 16-step screen-door dissolve to black (no
             * alpha blend on fa_surface). fade counts 16 -> 0; row y goes
             * black once (y & 15) >= fade. */
            int fade = fa_death_fade_amount(&s->death);
            if (fade > 0 && fade < FA_DEATH_FADE_TICKS) {
                for (int y = 0; y < h; y++) {
                    if ((y & 15) < fade) continue;
                    fa_rect r = { 0, y, w, 1 };
                    fa_fill(&dst, &r, NULL, 0);
                }
            }
        }
        return;
    }
    for (int y = 0; y < h; y++) {
        uint16_t *row = (uint16_t *)((uint8_t *)fb + (size_t)y * pitch);
        for (int x = 0; x < w; x++) {
            int gx = x + s->cam.x, gy = y + s->cam.y;
            row[x] = fa_rgb565((uint8_t)(gx >> 2), (uint8_t)(gy >> 2),
                               (uint8_t)((gx ^ gy) >> 3));
        }
    }
}

static int s_audio(int16_t *buf, int max_frames, int rate, int channels,
                   void *user)
{
    slice *s = (slice *)user;
    if (rate <= 0 || channels <= 0) return 0;

    /* with GData the real mixer owns the buffer; the 440 Hz tone is the
     * no-GData dev aid. */
    if (s->audio && channels == 2) {
        if (max_frames > 4096) max_frames = 4096;
        return fa_audio_mix(s->audio, buf, max_frames);
    }

    int chime = s->want_chime && s->chime_pos < rate;   /* 1 s startup tone */
    if (!s->tone && !chime) return 0;

    int emit = max_frames;
    if (!s->tone && emit > rate - s->chime_pos) emit = rate - s->chime_pos;

    const double step = 2.0 * 3.14159265358979 * 440.0 / rate;
    const int    ramp = rate / 20;                      /* 50 ms fades */
    for (int i = 0; i < emit; i++) {
        double amp = 4800.0;                            /* ~15 % */
        if (!s->tone) {
            int pos = s->chime_pos + i;
            int d = pos < rate - pos ? pos : rate - pos;
            if (d < ramp) amp *= (double)d / ramp;
        }
        int16_t v = (int16_t)(sin(s->tone_phase) * amp);
        s->tone_phase += step;
        if (s->tone_phase > 6.28318530718) s->tone_phase -= 6.28318530718;
        for (int c = 0; c < channels; c++) buf[i * channels + c] = v;
    }
    if (!s->tone) s->chime_pos += emit;
    return emit;
}

/*
 * Load a level under `maps`. `w01suf` / `w02suf` pick the variant: "" + "" =
 * main world, "t" + "t" = tutorial, "" + "E" = boss arena (WeltNE.W02 on the
 * parent world's WeltN.W01; there is no WeltNE.W01).
 */
static int load_world(slice *s, const char *maps, int world,
                      const char *w01suf, const char *w02suf)
{
    const char *variants[] = { "Welt%d%s.W01", "WELT%d%s.W01", "welt%d%s.w01" };
    const char *pvariants[] = { "Welt%d%s.W02", "WELT%d%s.W02", "welt%d%s.w02" };
    char path[600];

    for (unsigned v = 0; v < 3; v++) {
        char name[64];
        snprintf(name, sizeof name, variants[v], world, w01suf);
        snprintf(path, sizeof path, "%s/Maps/%s", maps, name);
        if (fa_w01_open_file(&s->bg, path) == 0) break;
        if (v == 2) return -1;
    }
    for (unsigned v = 0; v < 3; v++) {
        char name[64];
        snprintf(name, sizeof name, pvariants[v], world, w02suf);
        snprintf(path, sizeof path, "%s/Maps/%s", maps, name);
        if (fa_map_load_file(&s->map, path) == 0) {
            fa_tileset_free(s->tiles);
            s->tiles = fa_tileset_build(&s->bg, &s->map);
            fa_beh_free(s->beh);        /* drop behaviours before their store */
            s->beh = NULL;
            fa_entity_free(s->ents);
            s->ents = fa_entity_load(&s->map, maps);
            if (s->ents)
                printf("entities: %d placed, %d drawable, %d AOM defs\n",
                       fa_entity_count(s->ents), fa_entity_drawable(s->ents),
                       fa_entity_def_count(s->ents));
            return 0;
        }
        if (v == 2) { fa_w01_close(&s->bg); return -1; }
    }
    return -1;
}

/*
 * --custom1: load an arbitrary .W02 as the level. The map carries no art of
 * its own (the Rayman importer paints every cell from one atlas tile), so the
 * background pool is the shipped GIUNGLA sheet Welt1.W01.
 */
static int load_custom(slice *s, const char *maps, const char *w02_path)
{
    const char *variants[] = { "Welt1.W01", "WELT1.W01", "welt1.w01" };
    char path[600];

    for (unsigned v = 0; v < 3; v++) {
        snprintf(path, sizeof path, "%s/Maps/%s", maps, variants[v]);
        if (fa_w01_open_file(&s->bg, path) == 0) break;
        if (v == 2) return -1;
    }
    if (fa_map_load_file(&s->map, w02_path) != 0) {
        fa_w01_close(&s->bg);
        return -1;
    }
    fa_tileset_free(s->tiles);
    s->tiles = fa_tileset_build(&s->bg, &s->map);
    fa_beh_free(s->beh);
    s->beh = NULL;
    fa_entity_free(s->ents);
    s->ents = fa_entity_load(&s->map, maps);
    if (s->ents)
        printf("entities: %d placed, %d drawable, %d AOM defs\n",
               fa_entity_count(s->ents), fa_entity_drawable(s->ents),
               fa_entity_def_count(s->ents));
    return 0;
}

static int dir_has_gdata(const char *dir)
{
    char p[600];
    const char *probes[] = {
        "%s/Pics/StartBG.bmp", "%s/Pics/startbg.bmp", "%s/Maps/Welt2.W02"
    };
    for (unsigned i = 0; i < 3; i++) {
        snprintf(p, sizeof p, probes[i], dir);
        FILE *f = fopen(p, "rb");
        if (f) { fclose(f); return 1; }
    }
    return 0;
}

/* No GData tree found: report and stop. Shows a message box when SDL2 is in
 * the build so a double-click launch is not a silent failure. */
static int fatal_no_gdata(const char *path)
{
    (void)path;
    static const char msg[] =
        "GData folder not found.\n\n"
        "The GData assets folder from the Fresh Adventures CD-ROM is required.";
    fprintf(stderr, "%s\n", msg);
#if defined(FA_HAVE_SDL2)
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "OpenFA", msg, NULL);
#endif
    return 1;
}

/* Fill `out` with a GData path to try: --gdata, then the executable's own
 * directory, then platform fallbacks (Switch SD card, XDG data home), then a
 * bare "GData". The exe dir is used because launchers rarely set the CWD. */
static void find_gdata(const char *arg, const char *exe_path,
                       char *out, size_t cap)
{
    if (arg && *arg) { snprintf(out, cap, "%s", arg); return; }

#if defined(_WIN32)
    (void)exe_path;                     /* GetModuleFileNameA is used instead */
    char exe[MAX_PATH];
    DWORD n = GetModuleFileNameA(NULL, exe, sizeof exe);
    if (n > 0 && n < sizeof exe) {
        char *slash = strrchr(exe, '\\');
        if (slash) *slash = 0;
        char cand[MAX_PATH + 16];
        snprintf(cand, sizeof cand, "%s\\GData", exe);
        if (dir_has_gdata(cand)) { snprintf(out, cap, "%s", cand); return; }
    }
#elif defined(__SWITCH__)
    if (exe_path && exe_path[0]) {
        char dir[700];
        snprintf(dir, sizeof dir, "%s", exe_path);
        char *slash = strrchr(dir, '/');
        if (slash) {
            *slash = '\0';
            char cand[760];
            snprintf(cand, sizeof cand, "%s/GData", dir);
            if (dir_has_gdata(cand) && strlen(cand) + 1 <= cap) {
                memcpy(out, cand, strlen(cand) + 1);
                return;
            }
        }
    }

    /* a directory install plus a convenient SD-card root layout */
    const char *cands[] = {
        "sdmc:/switch/freshadventures/GData",
        "sdmc:/switch/FreshAdventures/GData",
        "sdmc:/GData"
    };
    for (size_t i = 0; i < sizeof cands / sizeof cands[0]; i++) {
        if (dir_has_gdata(cands[i])) {
            snprintf(out, cap, "%s", cands[i]);
            return;
        }
    }
#else
    /* POSIX desktop: <exe dir>/GData. */
    char base[700];
    base[0] = '\0';

    /* An AppImage runs from a throwaway mount, so /proc/self/exe is useless;
     * $APPIMAGE is the .AppImage file itself - look beside that. */
    const char *appimg = getenv("APPIMAGE");
    if (appimg && appimg[0]) {
        char d[700];
        snprintf(d, sizeof d, "%s", appimg);
        char *s = strrchr(d, '/');
        if (s) {
            *s = '\0';
            char cand[760];
            snprintf(cand, sizeof cand, "%s/GData", d);
            if (dir_has_gdata(cand) && strlen(cand) + 1 <= cap) {
                snprintf(out, cap, "%s", cand);
                return;
            }
        }
    }

#  if defined(__linux__)
    ssize_t ln = readlink("/proc/self/exe", base, sizeof base - 1);
    if (ln > 0) base[ln] = '\0'; else base[0] = '\0';
#  endif
    if (!base[0] && exe_path && strchr(exe_path, '/'))
        snprintf(base, sizeof base, "%s", exe_path);
    if (base[0]) {
        char *slash = strrchr(base, '/');
        if (slash) {
            *slash = '\0';
            char cand[760];
            snprintf(cand, sizeof cand, "%s/GData", base);
            if (dir_has_gdata(cand) && strlen(cand) + 1 <= cap) {
                snprintf(out, cap, "%s", cand);
                return;
            }
        }
    }

    /* XDG data-home fallback: $XDG_DATA_HOME/OpenFA/GData or
     * ~/.local/share/OpenFA/GData - also the path the Flatpak manifest
     * exposes, so one copy works sandboxed or not. */
    {
        const char *xdg = getenv("XDG_DATA_HOME");
        const char *home = getenv("HOME");
        char cand[760];
        if (xdg && xdg[0])
            snprintf(cand, sizeof cand, "%s/OpenFA/GData", xdg);
        else if (home && home[0])
            snprintf(cand, sizeof cand, "%s/.local/share/OpenFA/GData", home);
        else
            cand[0] = '\0';
        if (cand[0] && dir_has_gdata(cand) && strlen(cand) + 1 <= cap) {
            snprintf(out, cap, "%s", cand);
            return;
        }
    }
#endif
    snprintf(out, cap, "GData");
}

int main(int argc, char **argv)
{
    long frames = 0;
    const char *gdata_arg = NULL;
    int world = 0, tut = 0, end = 0, grid = 0, tone = 0, silent = 0, mute = 0, vol = -1;
    int show_credits = 0;
    int win_scale = 0, fullscreen = 0, crisp = 0;
    int debug_keys = 0;             /* -debug: unlock the I/P dev keys */
    double ov_g = 0, ov_j = 0, ov_j2 = 0, ov_r = 0, ov_a = 0;
    int ov_bw = 0, ov_bh = 0, ov_crail = 0, ov_cband = 0, ov_cb = 0;
    long seed_arg = -1;              /* >=0 pins the enemy RNG seed */
    const char *custom1 = NULL;      /* --custom1 PATH: load this .W02 as the level */

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--frames") && i + 1 < argc)
            frames = strtol(argv[++i], NULL, 0);
        else if (!strcmp(argv[i], "--gdata") && i + 1 < argc)
            gdata_arg = argv[++i];
        else if (!strcmp(argv[i], "--world") && i + 1 < argc)
            world = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--custom1") && i + 1 < argc)
            custom1 = argv[++i];
        else if (!strcmp(argv[i], "--tut"))    tut = 1;
        else if (!strcmp(argv[i], "--credits")) show_credits = 1;
        else if (!strcmp(argv[i], "--end"))    end = 1;   /* boot into WeltNE */
        else if (!strcmp(argv[i], "--grid"))   grid = 1;
        else if (!strcmp(argv[i], "--tone"))   tone = 1;
        else if (!strcmp(argv[i], "--silent")) silent = 1;
        else if (!strcmp(argv[i], "--mute"))   mute = 1;
        else if (!strcmp(argv[i], "--vol") && i + 1 < argc) vol = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--seed") && i + 1 < argc) seed_arg = strtol(argv[++i], NULL, 0);
        else if (!strcmp(argv[i], "--scale") && i + 1 < argc) win_scale = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--fullscreen")) fullscreen = 1;
        else if (!strcmp(argv[i], "-debug") || !strcmp(argv[i], "--debug"))
            debug_keys = 1;
        else if (!strcmp(argv[i], "--crisp"))      crisp = 1;
        else if (!strcmp(argv[i], "--gravity")   && i + 1 < argc) ov_g  = atof(argv[++i]);
        else if (!strcmp(argv[i], "--jumpvel")   && i + 1 < argc) ov_j  = atof(argv[++i]);
        else if (!strcmp(argv[i], "--jumpvel2")  && i + 1 < argc) ov_j2 = atof(argv[++i]);
        else if (!strcmp(argv[i], "--runspeed")  && i + 1 < argc) ov_r  = atof(argv[++i]);
        else if (!strcmp(argv[i], "--airaccel")  && i + 1 < argc) ov_a  = atof(argv[++i]);
        else if (!strcmp(argv[i], "--bboxw")     && i + 1 < argc) ov_bw = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--bboxh")     && i + 1 < argc) ov_bh = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--camrail")   && i + 1 < argc) ov_crail = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--camband")   && i + 1 < argc) ov_cband = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--cambias")   && i + 1 < argc) ov_cb = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            printf("OpenFA [--gdata DIR] [--world 1..4] [--tut|--end] "
                   "[--custom1 FILE.W02] "
                   "[--credits] [--grid] "
                   "[--tone|--silent|--mute] [--vol N] [--frames N]\n"
                    "  --custom1 FILE.W02: load this map (e.g. from "
                    "tools/rayimport.py) as the level; uses GIUNGLA art\n"
                    "  no --world: the menu - click a world circle, or use arrows / D-pad\n"
                    "           and Enter / controller A to play it\n"
                   "  --credits: roll the credits screen (Credit1..4.bmp + "
                   "ENDTITLES), then the menu\n"
                   "  a world with tut.ini byte 0 loads its tutorial (WeltNt) "
                   "automatically; --tut forces it\n"
                    "  -debug: unlock the dev keys - in a level P toggles "
                    "free-move (no-clip fly; hold A to dash) and I skips to "
                    "this world's boss arena\n"
                    "  local co-op: press ENTER or controller START; P2 uses "
                    "I/J/K/L + U/O + T, or the joining controller + LB\n"
                   "  audio: with GData the real mixer plays music + voice "
                   "(--mute off, --vol 0..255); no GData -> a 440 Hz tone "
                   "(--tone keeps it, --silent off)\n"
                   "  --seed N: pin the enemy RNG (default: wall clock, "
                   "like the retail exe)\n"
                   "  --scale N: open the window at N x 800x600 (render stays "
                   "800x600, scaled up to fill); --fullscreen fills the "
                   "display; --crisp keeps whole-number scaling (sharp pixels, "
                   "black bars)\n"
                   "  physics tuning (px/tick): --gravity 0.6 --jumpvel 11 "
                   "--jumpvel2 9 --runspeed 5 --airaccel 1.2\n"
                   "    (--jumpvel = Pinguì, --jumpvel2 = Milchschnitte; D switches)\n"
                   "  collision (px): --bboxw 10 --bboxh 44\n"
                   "  camera (px, exe-pinned): --camrail 130 (screen column "
                   "the character rides, flips with facing) --camband 200 (vertical "
                   "follow-band height) --cambias 0 (shift the band; + = look "
                   "down)\n");
            return 0;
        }
    }

    slice s;
    memset(&s, 0, sizeof s);
    s.grid = grid;
    s.tone = tone;
    s.want_chime = !tone && !silent;
    s.mute = mute;
    s.vol = vol;
    s.hover = -1;
    s.menu_focus = -1;
    s.p1_controller = -1;
    s.p2_controller = -1;
    s.keyboard_roles_swapped = 0;
    s.ov_gravity = ov_g; s.ov_jumpvel = ov_j; s.ov_jumpvel2 = ov_j2;
    s.ov_runspeed = ov_r; s.ov_airaccel = ov_a;
    s.ov_bboxw = ov_bw; s.ov_bboxh = ov_bh;
    s.ov_camrail = ov_crail; s.ov_camband = ov_cband; s.ov_cambias = ov_cb;
    s.rng_seed_set = seed_arg >= 0;
    s.rng_seed = s.rng_seed_set ? (uint32_t)seed_arg : (uint32_t)time(NULL);
    printf("enemy rng seed: %u%s\n", s.rng_seed,
           s.rng_seed_set ? " (--seed)" : " (clock)");
    fa_camera_init(&s.cam, FA_FB_W, FA_FB_H, FA_FB_W, FA_FB_H);

#if defined(__SWITCH__)
    /* stdio's sdmc: devoptab is not mounted by the game engine itself. */
    fsdevMountSdmc();
#endif
    find_gdata(gdata_arg, (argc > 0) ? argv[0] : NULL,
               s.gdata, sizeof s.gdata);
    char *gdata = s.gdata;

    /* No assets, no game. Only --frames and the --tone / --grid test pattern
     * may run without a GData tree. */
    if (!dir_has_gdata(gdata) && frames <= 0 && !tone && !grid)
        return fatal_no_gdata(gdata);

    /* the mixer needs the GData directory. */
    if (!mute && dir_has_gdata(gdata)) {
        s.audio = fa_audio_create(gdata);
        if (s.audio) {
            /* shipped Option.ini defaults: music 75, sound 100 */
            fa_audio_set_music_volume_ini(s.audio, 75);
            fa_audio_set_sfx_volume_ini(s.audio, 100);
            if (vol >= 0) fa_audio_set_master(s.audio, vol);
        }
    }

    if (show_credits && dir_has_gdata(gdata)) {
        s.credits = fa_credits_load(gdata);
        if (s.credits) {
            fa_credits_begin(s.credits);
            if (s.audio) fa_audio_event(s.audio, FA_SND_MENU_MUSIC);
            printf("credits: %d pages, then ENDTITLES; any key advances a "
                   "page, Esc quits\n", fa_credits_page_count(s.credits));
        } else {
            printf("credits: Credit1.bmp not found under %s\n", gdata);
        }
    } else if (custom1) {
        if (load_custom(&s, gdata, custom1) == 0) {
            s.have_map = 1;
            s.world = 1;                 /* GIUNGLA art + music + boss gate */
            s.in_end = 0;
            if (s.audio) fa_audio_event(s.audio, FA_SND_MUSIC_W1);
            fa_camera_init(&s.cam, FA_FB_W, FA_FB_H, s.map.world_w, s.map.world_h);
            s.use_player = 1;
            wire_level(&s);
            load_kids(&s);
            s.hud = fa_hud_load(gdata);
            printf("hud: %s\n", s.hud ? "loaded" : "absent");
            printf("loaded custom level %s: grid %dx%d, world %dx%d px, "
                   "bg %d frames\n", custom1,
                   s.map.info.grid_w, s.map.info.grid_h,
                   s.map.world_w, s.map.world_h, fa_w01_count(&s.bg));
        } else {
            printf("could not load custom level '%s' (or Welt1.W01 under %s)\n",
                   custom1, gdata);
        }
    } else if (world >= 1 && world <= 4) {
        const char *w1s = end ? "" : slice_world_suffix(gdata, world, tut);
        const char *w2s = end ? "E" : w1s;
        if (load_world(&s, gdata, world, w1s, w2s) == 0) {
            s.have_map = 1;
            s.world = world;
            s.in_end = end;
            if (s.audio)
                fa_audio_event(s.audio, end
                    ? FA_SND_MUSIC_BOSS
                    : (fa_snd_event)(FA_SND_MUSIC_W1 + world - 1));
            fa_camera_init(&s.cam, FA_FB_W, FA_FB_H, s.map.world_w, s.map.world_h);
            s.use_player = 1;
            wire_level(&s);
            load_kids(&s);
            s.hud = fa_hud_load(gdata);
            printf("hud: %s\n", s.hud ? "loaded" : "absent");
            printf("loaded Welt%d%s from %s: grid %dx%d, world %dx%d px, "
                   "bg %d frames\n", world, end ? "E" : w1s, gdata,
                   s.map.info.grid_w, s.map.info.grid_h,
                   s.map.world_w, s.map.world_h, fa_w01_count(&s.bg));
        } else {
            printf("could not load Welt%d from %s\n", world, gdata);
        }
    } else {
        slice_set_menu(&s, fa_menu_load(gdata));
        if (s.menu) {
            if (s.audio) fa_audio_event(s.audio, FA_SND_MENU_MUSIC);
            printf("loaded the title / world-select menu from %s (%d buttons)\n",
                   gdata, fa_menu_button_count(s.menu));
            for (int i = 0; i < fa_menu_button_count(s.menu); i++) {
                int x, y, w, h;
                fa_menu_hit_rect(s.menu, i, &x, &y, &w, &h);
                printf("  %-7s at %d,%d  %dx%d\n",
                       fa_menu_label(s.menu, i), x, y, w, h);
            }
        } else {
            printf("no GData at '%s' - showing the test pattern. Put GData "
                   "beside the .exe, or pass --gdata DIR.\n", gdata);
        }
    }

    if (s.menu)
        printf("click a world circle to play it (GIUNGLA = world 1), or use "
               "arrows / D-pad + Enter / controller A; ESCI to quit.\n");

    fa_app_cbs cbs;
    memset(&cbs, 0, sizeof cbs);
    cbs.sim = s_sim; cbs.render = s_render; cbs.audio = s_audio;
    cbs.should_quit = s_quit; cbs.user = &s;

    fa_platform_cfg cfg;
    memset(&cfg, 0, sizeof cfg);
    cfg.title = "OpenFA";
    cfg.want_audio = 1;
    cfg.integer_scale = crisp ? 1 : 0;   /* default: fill the window/screen */
    cfg.window_scale = win_scale;
    cfg.fullscreen = fullscreen;

    fa_app_set_debug_keys(debug_keys);

    fa_app_stats st;
    int rc = fa_app_run(&cfg, &cbs, frames, &st);
    printf("backend=%s frames=%llu ticks=%llu clamped=%llu hash=0x%08x rc=%d\n",
           st.backend, (unsigned long long)st.frames,
           (unsigned long long)st.ticks, (unsigned long long)st.clamped_frames,
           st.final_frame_hash, rc);
    if (strcmp(st.backend, "null") == 0 && frames <= 0)
        printf("NOTE: ran on the headless backend (no SDL2 / no display).\n");

    if (s.audio) fa_audio_destroy(s.audio);
    if (s.credits) fa_credits_free(s.credits);
    if (s.scores) fa_hiscore_free(s.scores);
    if (s.menu) fa_menu_free(s.menu);
    free_kids(&s);
    fa_hud_free(s.hud);
    fa_beh_free(s.beh);
    fa_tileset_free(s.tiles);
    fa_entity_free(s.ents);
    if (s.have_map) { fa_map_free(&s.map); fa_w01_close(&s.bg); }
    return rc;
}
